<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShippingContainer extends Model
{
    use HasFactory;
    protected $fillable = ['container_no','freight','seal_ref_no','address','contact_no','status','is_deleted'];
}
