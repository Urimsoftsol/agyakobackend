<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAdresses extends Model
{
    use HasFactory;
    protected $fillable = ['type','name','email','phone','alt_phones','address','post_code','latitude','longitude','customer_id'];

    public function getAltPhonesAttribute($value){
        if($value){
            return unserialize($value);
        }
        return array();
    }
}
