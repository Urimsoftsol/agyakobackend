<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookingDeliveryDrivers extends Model
{
    use HasFactory;
    protected $fillable = ['booking_id','driver_id','delivered_date','is_deliverred','is_failed'];
}
