<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;

class BookingProducts extends Model
{
    use HasFactory;
    protected $fillable = ['product_id','product_title','is_fragile','price','quantity','sub_amount','booking_id','item_id','is_loaded','is_wh_received','is_container_loaded','is_shipped','container_id','shipping_id','is_ship_received','is_deliverred','delivered_date','is_out_for_delivery'];
    protected $appends = ['parent_id','parent', 'no_of_child','product_title_new','status_text','container_name'];

    public function getProductTitleNewAttribute(){
        if(isset($this->attributes['product_id']) && isset($this->attributes['product_title'])){
            if(intval($this->attributes['product_id']) > 0){
                $cat = DB::table('products')->where('id',$this->attributes['product_id'])->first();
                if($cat){
                    if(intval($cat->parent_id) === 0){
                        return $this->attributes['product_title'];
                    }else{
                        $catName = DB::table('products')->where('id',$cat->parent_id)->pluck('title')->first();

                        return $catName.' - '.$this->attributes['product_title'];
                    }
                }
            }else{
                return 'Other - '.$this->attributes['product_title'];
            }
        }
        return '';
    }

    public function getProductIdAttribute($value){
        if($value == 0){
            return -1;
        }
        return $value;
    }

    public function getParentAttribute(){
        if(isset($this->attributes['product_id']) && intval($this->attributes['product_id'])){
            $parentId = DB::table('products')->where('id',$this->attributes['product_id'])->pluck('parent_id')->first();

            if($parentId){
                return DB::table('products')->where('id',$parentId)->select('id','title')->first();
            }

        }
        return null;
    }

     public function getParentIdAttribute(){
        if(isset($this->attributes['product_id']) && intval($this->attributes['product_id'])){
            return DB::table('products')->where('id',$this->attributes['product_id'])->pluck('parent_id')->first();
        }
        return 999;
    }

    public function getNoOfChildAttribute(){
        if(isset($this->attributes['parent_id'])){
            $data = DB::table('products')->where('id',$this->attributes['parent_id'])->get()->count();
            return $data;
        }
        return 0;
    }

    public function pickup_data(){
        return $this->belongsTo('App\Models\BookingUserDetails', 'booking_id', 'booking_id')->where('type','pickup');
    }
    public function recepient_data(){
        return $this->belongsTo('App\Models\BookingUserDetails', 'booking_id', 'booking_id')->where('type','dropoff');
    }
    public function booking_status(){
        return $this->belongsTo('App\Models\Bookings', 'booking_id', 'id')->select('status','id');
    }
    public function booking(){
        return $this->belongsTo('App\Models\Bookings', 'booking_id', 'id');
    }

    public function driver(){
        return $this->hasOne('App\Models\BookingDrivers','booking_id', 'booking_id')->join('drivers','drivers.id','=','booking_drivers.driver_id')->select('booking_drivers.driver_id as id','booking_drivers.booking_id','drivers.name','booking_drivers.created_at as assigned_date')->where('booking_drivers.is_cancel',0);
    }

    public function images(){
        return $this->hasMany('App\Models\BookingProductImage','booking_product_id')->where('is_delivery',0);
    }

    public function getStatusTextAttribute(){
        if(isset($this->attributes['is_deliverred']) && $this->attributes['is_deliverred'] == 1){
            return 'Delivered - Ghana';
        }
        if(isset($this->attributes['is_out_for_delivery']) && $this->attributes['is_out_for_delivery'] == 1){
            return 'Item Out For Delivery - Ghana';
        }
        
        if(isset($this->attributes['is_ship_received']) && $this->attributes['is_ship_received'] == 1){
            return 'Received In Warehouse - Ghana';
        }

        if(isset($this->attributes['is_shipped']) && $this->attributes['is_shipped'] == 1){
            return 'Shipped From Warehouse - UK';
        }

        if(isset($this->attributes['is_container_loaded']) && $this->attributes['is_container_loaded'] == 1){
            return 'Item Loaded In Container';
        }

        if(isset($this->attributes['is_wh_received']) && $this->attributes['is_wh_received'] == 1){
            return 'Item In Warehouse - UK';
        }

        if(isset($this->attributes['is_loaded']) && $this->attributes['is_loaded'] == 1){
            return 'Item Picked Up - UK';
        }
        
        return '';
    }

    public function getContainerNameAttribute(){
        if(isset($this->attributes['container_id']) && $this->attributes['container_id'] > 0){
            $coName = DB::table('shipping_containers')->where('id',$this->attributes['container_id'])->pluck('container_no')->first();
            if($coName){
                return $coName;
            }
        }
        
        return ' - ';
    }
}
