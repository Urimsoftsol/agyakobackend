<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GuestCustomer extends Model
{
    use HasFactory;
    protected $fillable = ['customer_id','name','email','phone','alt_phones','address','post_code','latitude','registered_company','company_name','company_shipping','longitude'];
}
