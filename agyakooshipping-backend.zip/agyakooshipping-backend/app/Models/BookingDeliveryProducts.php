<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;

class BookingDeliveryProducts extends Model
{
    use HasFactory;
    protected $fillable = ['product_id','product_title','price','quantity','sub_amount','booking_id','item_id'];
    protected $appends = ['parent', 'no_of_child','product_title_new'];

    public function getProductTitleNewAttribute(){
        if(isset($this->attributes['product_id']) && isset($this->attributes['product_title'])){
            if(intval($this->attributes['product_id']) > 0){
                $cat = DB::table('delivery_products')->where('id',$this->attributes['product_id'])->first();
                if($cat){
                    if(intval($cat->parent_id) === 0){
                        return $this->attributes['product_title'];
                    }else{
                        $catName = DB::table('delivery_products')->where('id',$cat->parent_id)->pluck('title')->first();

                        return $catName.' - '.$this->attributes['product_title'];
                    }
                }
            }else{
                return 'Other - '.$this->attributes['product_title'];
            }
        }
        return '';
    }

    public function getParentAttribute(){
        if(isset($this->attributes['parent_id']) && intval($this->attributes['parent_id'])){
            $parent = DB::table('delivery_products')->where('id',$this->attributes['parent_id'])->select('id','title')->first();
            return $parent;
        }
        return null;
    }

    public function getNoOfChildAttribute(){
        if(isset($this->attributes['parent_id'])){
            $data = DB::table('delivery_products')->where('id',$this->attributes['parent_id'])->get()->count();
            return $data;
        }
        return 0;
    }
}
