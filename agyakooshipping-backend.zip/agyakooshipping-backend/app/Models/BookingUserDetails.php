<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookingUserDetails extends Model
{
    use HasFactory;
    protected $fillable = ['type','name_title','name','email','phone','alt_phones','booking_id','user_id','status','primary_id','address','post_code','latitude','longitude'];

    public function getAltPhonesAttribute($value){
        if($value){
            return unserialize($value);
        }
        return array();
    }
}
