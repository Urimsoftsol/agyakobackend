<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;
class Customer extends Model
{
    use HasFactory;
    protected $fillable = ['customer_id','user_id','name','email','phone','alt_phones','address','post_code','latitude','registered_company','company_name','company_shipping','longitude','dob','status','is_deleted'];
    protected $appends = ['name_initials','current_membership','membership_expired_date','membership_discount','membership_duration'];

    public function getAltPhonesAttribute($value){
        if($value){
            return unserialize($value);
        }
        return array();
    }

    public function getNameInitialsAttribute(){
        if(isset($this->attributes['name'])){
            $res = '';
            $name = $this->attributes['name'];
            $nameArr = explode(' ', $name);
            $res .= substr($nameArr[0],0,1);
            if(count($nameArr) > 1){
                $res .= substr($nameArr[1],0,1);
            }

            return strtoupper($res);
        }
        return '';
    }
        public function getCurrentMembershipAttribute(){
            // return "new";
        if(isset($this->attributes['id'])){
           // $con = DB::table('customer_memberships')->where('customer_id',$this->attributes['id'])->pluck('expired_date');
            $con =  DB::table('customer_memberships')->join('memberships','customer_memberships.membership_id','=','memberships.id')->where('customer_memberships.customer_id',$this->attributes['id'])->whereDate('customer_memberships.expired_date', '>', now()->today())->pluck('memberships.name')->first();
            
            return $con;
        }
        return '';
    }
    public function getMembershipExpiredDateAttribute(){
            // return "new";
        if(isset($this->attributes['id'])){
            $con = DB::table('customer_memberships')->where('customer_id',$this->attributes['id'])->whereDate('customer_memberships.expired_date', '>', now()->today())->pluck('expired_date')->first();
           // $con =  DB::table('customer_memberships')->join('memberships','customer_memberships.membership_id','=','memberships.id')->where('customer_memberships.customer_id',$this->attributes['id'])->pluck('memberships.name')->first();
            
            return $con;
        }
        return '';
    }
    public function getMembershipDiscountAttribute(){
            // return "new";
        if(isset($this->attributes['id'])){
            //$con = DB::table('customer_memberships')->where('customer_id',$this->attributes['id'])->pluck('discount')->first();
                        $con =  DB::table('customer_memberships')->join('memberships','customer_memberships.membership_id','=','memberships.id')->where('customer_memberships.customer_id',$this->attributes['id'])->whereDate('customer_memberships.expired_date', '>', now()->today())->pluck('memberships.discount')->first();

           // $con =  DB::table('customer_memberships')->join('memberships','customer_memberships.membership_id','=','memberships.id')->where('customer_memberships.customer_id',$this->attributes['id'])->pluck('memberships.name')->first();
            
            return $con;
        }
        return '';
    }
        public function getMembershipDurationAttribute(){
            // return "new";
        if(isset($this->attributes['id'])){
            $con =  DB::table('customer_memberships')->join('memberships','customer_memberships.membership_id','=','memberships.id')->where('customer_memberships.customer_id',$this->attributes['id'])->whereDate('customer_memberships.expired_date', '>', now()->today())->pluck('memberships.duration')->first();
            
            return $con;
        }
        return '';
    }
}
