<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;

class Bookings extends Model
{
    //Status = -1=>Cancelled

    use HasFactory;
    protected $fillable = ['reference_id','shipping_id','key_type','key_value','customer_id','customer_type','registered_company','company_name','company_shipping','insurance','is_delivery','no_of_items','description','amount','shipping','vat','total','paid_amount','pickup_date','pickup_time','booking_date','estimated_delivery_date','payment_status','shipping_status','status','complaint_status','added_by','last_edited_by','delivery_total','discount','post_code','customer_signature'];
    protected $appends = ['customer_name', 'created_user','created_user_type','edited_user','total_items','loaded_items','status_text','container_name'];

    public function customer(){
        return $this->belongsTo('App\Models\Customer', 'customer_id');
    }

    public function driver(){
        return $this->hasOne('App\Models\BookingDrivers','booking_id')->join('drivers','drivers.id','=','booking_drivers.driver_id')->select('booking_drivers.driver_id as id','booking_drivers.booking_id','drivers.name','booking_drivers.created_at as assigned_date')->where('booking_drivers.is_cancel',0);
    }

    public function delivery_driver(){
        return $this->hasOne('App\Models\BookingDeliveryDrivers','booking_id')->join('drivers','drivers.id','=','booking_delivery_drivers.driver_id')->select('drivers.name','booking_delivery_drivers.booking_id','booking_delivery_drivers.driver_id','booking_delivery_drivers.created_at','booking_delivery_drivers.updated_at','booking_delivery_drivers.delivered_date','booking_delivery_drivers.is_deliverred','booking_delivery_drivers.is_failed','drivers.email','drivers.mobile')->where('booking_delivery_drivers.is_failed',0);
    }

    public function picked_driver(){
        return $this->hasOne('App\Models\BookingDrivers','booking_id')->join('drivers','drivers.id','=','booking_drivers.driver_id')->select('booking_drivers.driver_id as id','booking_drivers.booking_id','drivers.name','drivers.email','drivers.mobile','booking_drivers.created_at as assigned_date');
    }

    public function guestCustomer(){
        return $this->belongsTo('App\Models\GuestCustomer', 'customer_id');
    }

    public function products(){
        return $this->hasMany('App\Models\BookingProducts','booking_id')->with('images');
    }

    public function delivery_products(){
        return $this->hasMany('App\Models\BookingDeliveryProducts','booking_id')->leftJoin('delivery_products','delivery_products.id','=','booking_delivery_products.product_id')->select('booking_delivery_products.id','booking_delivery_products.item_id','booking_delivery_products.booking_id','booking_delivery_products.sub_amount','booking_delivery_products.quantity','booking_delivery_products.product_title','booking_delivery_products.product_id','booking_delivery_products.price','delivery_products.parent_id');
    }

    public function products2(){
        return $this->hasMany('App\Models\BookingProducts','booking_id')->leftJoin('products','products.id','=','booking_products.product_id')->select('booking_products.*','products.title', 'products.parent_id', 'products.amount');
    }

    public function delivery_products2(){
        return $this->hasMany('App\Models\BookingDeliveryProducts','booking_id')->leftJoin('delivery_products','delivery_products.id','=','booking_delivery_products.product_id')->select('booking_delivery_products.*','delivery_products.title', 'delivery_products.parent_id', 'delivery_products.amount');
    }

    public function payments(){
        return $this->hasMany('App\Models\BookingPaymentHistory','booking_id')->leftJoin('users','users.id','=','booking_payment_histories.added_by')->select('booking_payment_histories.*','users.name');
    }

    public function pickup_details(){
        return $this->hasOne('App\Models\BookingUserDetails','booking_id')->where('type','pickup');
    }

    public function dropoff_details(){
        return $this->hasOne('App\Models\BookingUserDetails','booking_id')->where('type','dropoff');
    }

    public function tracking_details(){
        return $this->hasMany('App\Models\TrackBooking','booking_id');
    }

    public function images(){
        return $this->hasMany('App\Models\BookingProductImage','booking_id')->where('is_delivery',0);
    }

    public function delivery_images(){
        return $this->hasMany('App\Models\BookingProductImage','booking_id')->where('is_delivery',1);
    }

    public function getCustomerNameAttribute(){
        if(isset($this->attributes['customer_type']) && isset($this->attributes['customer_id'])){
            if($this->attributes['customer_type'] == 'Guest'){
                return DB::table('guest_customers')->where('id',$this->attributes['customer_id'])->pluck('name')->first();
            }
            if($this->attributes['customer_type'] == 'Registered'){
                return DB::table('customers')->where('id',$this->attributes['customer_id'])->pluck('name')->first();
            }
        }
        return '';
    }

    public function getCreatedUserAttribute(){
        if(isset($this->attributes['customer_type']) && isset($this->attributes['customer_id']) && isset($this->attributes['added_by'])){
            if($this->attributes['added_by'] != 0){
                return DB::table('users')->where('id',$this->attributes['added_by'])->pluck('name')->first();
            }else if($this->attributes['customer_type'] == 'Guest'){
                return DB::table('guest_customers')->where('id',$this->attributes['customer_id'])->pluck('name')->first();
            }else if($this->attributes['customer_type'] == 'Registered'){
                return DB::table('customers')->where('id',$this->attributes['customer_id'])->pluck('name')->first();
            }
        }
        return '';
    }

    public function getCreatedUserTypeAttribute(){
        if(isset($this->attributes['customer_type']) && isset($this->attributes['customer_id']) && isset($this->attributes['added_by'])){
            if($this->attributes['added_by'] != 0){
                return DB::table('users')->where('id',$this->attributes['added_by'])->pluck('user_type')->first();
            }else if($this->attributes['customer_type'] == 'Guest'){
                return 'Guest';
            }else if($this->attributes['customer_type'] == 'Registered'){
                return 'Registered';
            }
        }
        return '';
    }

    public function getEditedUserAttribute(){
        if(isset($this->attributes['customer_type']) && isset($this->attributes['customer_id']) && isset($this->attributes['last_edited_by']) && isset($this->attributes['detail_id'])){
            if($this->attributes['last_edited_by']){
                return DB::table('users')->where('id',$this->attributes['added_by'])->pluck('user_type')->first();
            }
        }
        return '-';
    }

    public function getTotalItemsAttribute(){
        if(isset($this->attributes['detail_id'])){
            return DB::table('booking_products')->where('booking_id', $this->attributes['detail_id'])->count();
        }
        return 0;
    }

    public function getLoadedItemsAttribute(){
        if(isset($this->attributes['detail_id'])){
            return DB::table('booking_products')->where('booking_id', $this->attributes['detail_id'])->where('is_loaded', 1)->count();
        }
        return 0;
    }

    public function getStatusTextAttribute(){
        if(isset($this->attributes['status'])){
            if($this->attributes['status'] == -1){
                return 'Order Cancelled - UK';
            }
            if($this->attributes['status'] == 0){
                return 'Order Booked - UK';
            }
            if($this->attributes['status'] == 1){
                return 'Item Assigned To Driver - UK';
            }
            if($this->attributes['status'] == 2){
                return 'Item Picked Up - UK';
            }
            if($this->attributes['status'] == 3){
                return 'Item In Warehouse - UK';
            }
            if($this->attributes['status'] == 4){
                return 'Item Shipped From Warehouse - UK';
            }
            if($this->attributes['status'] == 5){
                return 'Item Received In Warehouse - Ghana';
            }
            if($this->attributes['status'] == 6){
                return 'Item Out For Delivery - Ghana';
            }
            if($this->attributes['status'] == 7){
                return 'Delivered - Ghana';
            }
        }
        return '';
    }

    public function getContainerNameAttribute(){
        if(isset($this->attributes['shipping_id'])){
            return DB::table('shippings')->join('shipping_containers','shipping_containers.id','=','shippings.container_no')->where('shippings.id',$this->attributes['shipping_id'])->pluck('shipping_containers.container_no')->first();
        }
        return '';
    }

    public function getCustomerSignatureAttribute($value){
        if($value){
            return 'https://backend.agyakooshipping.com/storage/app/public/'.$value;
        }
        return null;
    }
}
