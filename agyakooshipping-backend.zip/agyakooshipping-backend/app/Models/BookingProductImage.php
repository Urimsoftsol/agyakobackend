<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookingProductImage extends Model
{
    use HasFactory;
    protected $fillable = ['image','booking_id','booking_product_id','is_delivery'];
    protected $appends = ['image_url'];

    public function getImageUrlAttribute(){
        if(isset($this->attributes['id']) && isset($this->attributes['image'])){
            if(!empty($this->attributes['image'])){
                return 'https://backend.agyakooshipping.com/storage/app/public/'.$this->attributes['image'];
            }
        }
        return '';
    }
}
