<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomerMembership extends Model
{
    use HasFactory;
    protected $fillable = ['customer_id','membership_id','starting_date','purchase_date','expired_date'];
}
