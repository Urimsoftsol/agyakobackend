<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB; 

class Shippings extends Model
{
    use HasFactory;
    protected $fillable = ['reference_id','container_no','shipping_from','shipping_to','shipping_date','arrival_date','eta_of_container','consignee','warehouse_location','status'];
    protected $appends = ['container_name','container_ref','freight','no_of_invoice'];

    public function getContainerNameAttribute(){
        if(isset($this->attributes['container_no'])){
            $con = DB::table('shipping_containers')->where('id',$this->attributes['container_no'])->select('container_no','seal_ref_no')->first();
            if($con){
                return $con->container_no.' ('.$con->seal_ref_no.')';
            }
        }
        return '';
    }

    public function getContainerRefAttribute(){
        if(isset($this->attributes['container_no'])){
            $con = DB::table('shipping_containers')->where('id',$this->attributes['container_no'])->pluck('seal_ref_no')->first();
            
            return $con;
        }
        return '';
    }

    public function getFreightAttribute(){
        if(isset($this->attributes['container_no'])){
            return DB::table('shipping_containers')->where('id',$this->attributes['container_no'])->pluck('freight')->first();
        }
        return '';
    }

    public function getNoOfInvoiceAttribute(){
        if(isset($this->attributes['id'])){
            $booking = DB::table('booking_products')->where('shipping_id',$this->attributes['id'])->select('id')->get()->toArray();
            return count($booking);
        }
        return 0;
    }
}
