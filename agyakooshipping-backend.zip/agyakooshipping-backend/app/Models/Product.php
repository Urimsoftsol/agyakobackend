<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;

class Product extends Model
{
    use HasFactory;
    protected $fillable = ['title','parent_id','amount','status','is_fragile'];
    protected $appends = ['parent', 'no_of_child'];

    public function children(){
        return $this->hasMany('App\Models\Product', 'parent_id', 'id');
    }

    public function getParentAttribute(){
        if(isset($this->attributes['parent_id']) && intval($this->attributes['parent_id'])){
            $parent = DB::table('products')->where('id',$this->attributes['parent_id'])->select('id','title')->first();
            return $parent;
        }
        return null;
    }

    public function getNoOfChildAttribute(){
        if(isset($this->attributes['id'])){
            $data = DB::table('products')->where('parent_id',$this->attributes['id'])->get()->count();
            return $data;
        }
        return 0;
    }
}
