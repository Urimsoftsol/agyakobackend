<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BookingPaymentHistory extends Model
{
    use HasFactory;
    protected $fillable = ['added_by','amount','note','booking_id','payment_method'];
}
