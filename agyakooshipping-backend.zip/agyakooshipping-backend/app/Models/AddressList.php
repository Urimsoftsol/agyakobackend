<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AddressList extends Model
{
    use HasFactory;
    protected $fillable = ['address','post_code','type','latitude','longitude'];
}
