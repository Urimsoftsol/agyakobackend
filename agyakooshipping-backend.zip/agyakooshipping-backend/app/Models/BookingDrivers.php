<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;

class BookingDrivers extends Model
{
    use HasFactory;
    protected $fillable = ['booking_id','driver_id','pickup_date','is_cancel','is_picked','is_received'];
    protected $appends = ['customer_name'];

    public function getCustomerNameAttribute(){
        if(isset($this->attributes['customer_type']) && isset($this->attributes['customer_id'])){
            if($this->attributes['customer_type'] == 'Guest'){
                return DB::table('guest_customers')->where('id',$this->attributes['customer_id'])->pluck('name')->first();
            }
            if($this->attributes['customer_type'] == 'Registered'){
                return DB::table('customers')->where('id',$this->attributes['customer_id'])->pluck('name')->first();
            }
        }
        return '';
    }
}
