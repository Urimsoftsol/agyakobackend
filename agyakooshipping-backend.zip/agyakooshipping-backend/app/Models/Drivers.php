<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Drivers extends Model
{
    use HasFactory;
    protected $fillable = ['driver_id','user_id','name','email','land_line','mobile','address','house_no','dob','driver_type','wage_type','location','status','is_deleted','type'];

    public function assigned_bookings(){
        return $this->hasMany('App\Models\BookingDrivers','driver_id')->join('bookings','bookings.id','=','booking_drivers.booking_id')->join('booking_user_details','bookings.id','=','booking_user_details.booking_id')->select('booking_drivers.id','booking_drivers.booking_id','booking_drivers.driver_id','booking_drivers.pickup_date','booking_drivers.is_cancel','booking_drivers.is_picked','bookings.reference_id','bookings.total','bookings.paid_amount','bookings.post_code','bookings.payment_status','bookings.created_at','bookings.customer_type','bookings.customer_id','booking_user_details.phone','booking_user_details.address')->where('bookings.status','!=',-1)->where('booking_user_details.type','pickup');
    }
}
