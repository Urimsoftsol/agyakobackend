<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class OrderShipped extends Mailable
{
    use Queueable, SerializesModels;

    public $code;

    public function __construct($params)
    {
        $this->params = $params;
    }

    public function build()
    {
        return $this
            ->subject('Agyakooshipping.com Order Shipped - '.$this->params['reference_id'])
            ->cc('millicent@agyakooshipping.co.uk')
            ->bcc('vtiontech@gmail.com')
            ->view('emails.order-shipped')
            ->with([
                'params' => $this->params
            ]);
    }
}
