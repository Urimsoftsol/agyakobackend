<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;
use App\Models\User;
use App\Models\Drivers;
use App\Models\Bookings;
use App\Models\BookingProducts;
use App\Models\BookingDrivers;
use App\Models\TrackBooking;
use App\Models\Shippings;
use App\Models\ShippingContainer;
use Validator;
use Auth;
use DB;

class WareHouseAppController extends Controller
{
    protected $user;

    public function __construct(Request $request){
        $bearerToken = $request->bearerToken();
        $token = PersonalAccessToken::findToken($bearerToken);
        if($token){
            $this->user = $token->tokenable;
        }
    }

    public function login(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['email'] = 'required';
        $rules['password'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        if (Auth::guard()->attempt(array('email'=>$postData['email'],'password'=>$postData['password']))) {
            $user = Auth::user();
            if($user->status == 1){
                if($user->user_type == 'Super Admin' || $user->user_type == 'UK Admin' || $user->user_type == 'Receptionist'){
                    $token = $user->createToken($user->name,array('*'),now()->addHours(24))->plainTextToken;
                    $user ->api_token = $token;

                    return response()->json(array(
                        'status' => 'SUCCESS',
                        'message' => 'Logged in successfully',
                        'data' => $user
                    ));
                }else{
                    return response()->json(array(
                        'status' => 'ERROR',
                        'message' => 'You can not access this app. Please contact admin.'
                    ));
                }
            }else{
                return response()->json(array(
                    'status' => 'ERROR',
                    'message' => 'This user is inactive now. Please contact admin.'
                ));
            }
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Sorry, that username or password is incorrect. Please try again.'
            ));
        }
    }

    public function getDriverList(){
        $subQuery = DB::table('booking_drivers')->join('bookings','booking_drivers.booking_id','=','bookings.id')->where('booking_drivers.is_picked',1)->where('booking_drivers.is_received',0)->select('booking_drivers.driver_id',DB::raw("SUM(bookings.total) as total"))->groupBy('booking_drivers.driver_id');

        $data = DB::table('drivers')->leftJoinSub($subQuery, 'subQuery', function ($join) {
            $join->on('subQuery.driver_id', '=', 'drivers.id');
        })->select('drivers.id','drivers.name','drivers.email',DB::raw("IFNULL(`subQuery`.`total`, 0) as total"))->orderBy('drivers.name')->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getBookingItemList($driverId){
        $bookingIds = DB::table('booking_drivers')->join('bookings','booking_drivers.booking_id','=','bookings.id')->where('booking_drivers.driver_id',$driverId)->where('booking_drivers.is_picked',1)->where('booking_drivers.is_received',0)->pluck('bookings.id')->toArray();

        $data = BookingProducts::whereIn('booking_id',$bookingIds)->where('is_loaded',1)->where('is_wh_received',0)->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function changeItemReceived($str){
        try{
            $str = base64_decode(base64_decode($str));

            $strArr = explode('-',$str);

            if(count($strArr) == 3){
                if($strArr[0] == 'AgyakooShipping'){
                    $bookingId = $strArr[1];
                    $bookingPId = $strArr[2];

                    $bpDet = BookingProducts::where('id',$bookingPId)->first();

                    if($bpDet['is_loaded'] == 0 || $bpDet['is_wh_received'] == 1){
                        return response()->json(array(
                            'status' => 'ERROR'
                        ));
                    }

                    BookingProducts::where('id',$bookingPId)->update(array('is_wh_received'=>1));

                    $bProducts = BookingProducts::where('booking_id',$bookingId)->where('is_wh_received',0)->get()->toArray();

                    if(count($bProducts) == 0){
                        Bookings::where('id',$bookingId)->update(array('status'=>3));
                        BookingDrivers::where('booking_id',$bookingId)->update(array('is_received'=>1));
                        TrackBooking::create(array('status'=>3,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));
                    }

                    return response()->json(array(
                        'status' => 'SUCCESS',
                        'message' => 'Status changed successfully.'
                    ));
                }
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'status' => 'ERROR'
            ));
        }
    }

    public function getWarehouseItemList(){
        $data = BookingProducts::where('is_wh_received',1)->where('is_container_loaded',0)->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getContainerList(){
        $shippingContainers = Shippings::where('status',1)->pluck('container_no')->toArray();

        $subQuery = DB::table('booking_products')->where('is_container_loaded',1)->where('is_shipped',0)->select('booking_products.container_id',DB::raw("SUM(booking_products.sub_amount) as total"))->groupBy('booking_products.container_id');

        $data = DB::table('shipping_containers')->leftJoinSub($subQuery, 'subQuery', function ($join) {
            $join->on('subQuery.container_id', '=', 'shipping_containers.id');
        })->whereNotIn('id',$shippingContainers)->select('shipping_containers.id','shipping_containers.container_no','shipping_containers.contact_no',DB::Raw('IFNULL( subQuery.total , 0 ) as total'))->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getContainerItemList($containerId){
        $data = BookingProducts::where('container_id',$containerId)->where('is_container_loaded',1)->where('is_shipped',0)->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function changeItemLoaded($containerId,$str){
        try{
            $str = base64_decode(base64_decode($str));

            $strArr = explode('-',$str);

            if(count($strArr) == 3){
                if($strArr[0] == 'AgyakooShipping'){
                    $bookingId = $strArr[1];
                    $bookingPId = $strArr[2];

                    $bpDet = BookingProducts::where('id',$bookingPId)->first();

                    if($bpDet['is_loaded'] == 0 || $bpDet['is_wh_received'] == 0 || $bpDet['is_container_loaded'] == 1){
                        return response()->json(array(
                            'status' => 'ERROR'
                        ));
                    }

                    BookingProducts::where('id',$bookingPId)->update(array('container_id'=>$containerId,'is_container_loaded'=>1));

                    return response()->json(array(
                        'status' => 'SUCCESS',
                        'message' => 'Status changed successfully.'
                    ));
                }
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'status' => 'ERROR'
            ));
        }
    }

    public function getShippingContainerList(){
        $subQuery = DB::table('booking_products')->select('booking_products.container_id',DB::raw("SUM(booking_products.sub_amount) as total"))->groupBy('booking_products.container_id');

        $data = DB::table('shipping_containers')->join('shippings','shippings.container_no','=','shipping_containers.id')->leftJoinSub($subQuery, 'subQuery', function ($join) {
            $join->on('subQuery.container_id', '=', 'shipping_containers.id');
        })->where('shippings.status',1)->select('shippings.id','shippings.reference_id','shipping_containers.container_no',DB::Raw('IFNULL( subQuery.total , 0 ) as total'))->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getShippingContainerItemList($shippingId){
        $data = BookingProducts::where('shipping_id',$shippingId)->where('is_shipped',1)->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }
}
