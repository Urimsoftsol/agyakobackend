<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Delivery_product;
use App\Models\Product;
use App\Models\Bookings;
use App\Models\BookingProducts;
use App\Models\BookingDeliveryProducts;
use App\Models\BookingUserDetails;
use App\Models\AddressList;
use App\Models\UserAdresses;
use App\Models\User;
use App\Models\GuestCustomer;
use App\Models\Customer;
use App\Models\TrackBooking;
use App\Models\Shippings;
use App\Models\ShippingContainer;
use Illuminate\Support\Facades\Hash;
use DB;
use App\Mail\ContactUs;
use Illuminate\Support\Facades\Mail;

class FrontController extends Controller
{
    public function addCustomer(Request $request){
        $postData = $request->all();

        $userData['name'] = $postData['name'];
        $userData['email'] = $postData['email'];
        $userData['phone'] = $postData['phone'];
        $userData['password'] = Hash::make($postData['password']);
        $userData['user_type'] = 'Customer';
        $userData['status'] = 1;
        $userData['latitude'] = $postData['latitude'];
        $userData['longitude'] = $postData['longitude'];

        $data = User::create($userData);

        if($data){
            $postData['user_id'] = $data->id;
            $postData['alt_phones'] = serialize($postData['alt_phones']);

            $customer = Customer::create($postData);
            if($customer){
                $str = 'C'.str_pad($customer->id, 5, "0", STR_PAD_LEFT);
                Customer::where('id',$customer->id)->update(array('customer_id'=>$str));
            }

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Customer list got successfully.',
                'data' => $customer->id
            ));
        }

    }
    public function getCustomerDDList(){
        $data = Customer::select('*','id as value',DB::raw("CONCAT(name,' (',customer_id,'), ',phone,', ',address)  AS label"))->orderBy('name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer list got successfully.',
            'data' => $data
        ));
    }

    public function getContainerDDList($isAdd){
        $onShip = array();
        if($isAdd){
            $onShip = Shippings::whereIn('status',[0,1,2])->pluck('container_no')->toArray();
        }
        $data = ShippingContainer::where('status',1)->whereNotIn('id',$onShip)->select('id as value',DB::raw("CONCAT(container_no,' (',seal_ref_no,')') AS label"))->orderBy('container_no')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Container list got successfully.',
            'data' => $data,
            'onShip' => $onShip,
        ));
    }

    public function getDeliveryProductList(){
        $data = Delivery_product::where('status',1)->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery Category list got successfully.',
            'data' => $data
        ));
    }

    public function getProductList(){
        $data = Product::where('status',1)->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery Category list got successfully.',
            'data' => $data
        ));
    }

    public function addBooking(Request $request){
        $postData = $request->all();

        $delivery_products = array();
        $products = array();
        $dropOffData = array();
        $pickUpData = array();

        if(isset($postData['delivery_products'])){
            $delivery_products = $postData['delivery_products'];
            unset($postData['delivery_products']);
        }

        if(isset($postData['products'])){
            $products = $postData['products'];
            unset($postData['products']);
        }

        if(isset($postData['dropOffData'])){
            $dropOffData = $postData['dropOffData'];
            unset($postData['dropOffData']);
        }

        if(isset($postData['pickUpData'])){
            $pickUpData = $postData['pickUpData'];
            unset($postData['pickUpData']);
        }
        if(empty($postData['company_name'])){
            unset($postData['company_name']);
        }

        $postData['booking_date'] = date('Y-m-d');
        $postData['estimated_delivery_date'] = date('Y-m-d',strtotime("+15 days", strtotime($postData['pickup_date'])));


        $data = Bookings::create($postData);

        if($data){
            $str = 'B'.str_pad($data->id, 6, "0", STR_PAD_LEFT);
            Bookings::where('id',$data->id)->update(array('reference_id'=>$str));
            TrackBooking::create(array('status'=>0,'datetime'=>$data->created_at,'booking_id'=>$data->id));

            if($data->customer_id == 0){
                Bookings::where('id',$data->id)->update(array('customer_type'=>'Guest'));
                $gcusomerData = array();
                $gcusomerData['name'] = $pickUpData['name'];
                $gcusomerData['email'] = $pickUpData['email'];
                $gcusomerData['phone'] = $pickUpData['phone'];
                $gcusomerData['alt_phones'] = serialize($pickUpData['alt_contact_nos']);
                $gcusomerData['address'] = $pickUpData['address'];
                $gcusomerData['post_code'] = $pickUpData['post_code'];
                if(isset($pickUpData['latitude'])){
                    $gcusomerData['latitude'] = $pickUpData['latitude'];
                }
                if(isset($pickUpData['longitude'])){
                    $gcusomerData['longitude'] = $pickUpData['longitude'];
                }

                $gCustomer = GuestCustomer::create($gcusomerData);
                if($gCustomer){
                    $str = 'G'.str_pad($gCustomer->id, 5, "0", STR_PAD_LEFT);
                    GuestCustomer::where('id',$gCustomer->id)->update(array('customer_id'=>$str));
                    Bookings::where('id',$data->id)->update(array('customer_id'=>$gCustomer->id));
                }
            }else{
                Bookings::where('id',$data->id)->update(array('customer_type'=>'Registered'));
            }

            $adr1 = AddressList::where('address',$pickUpData['address'])->where('type','pickup')->first();
            $adr2 = AddressList::where('address',$dropOffData['address'])->where('type','dropoff')->first();
            if(!$adr1){
                $addrNew = array();
                $addrNew['address'] = $pickUpData['address'];
                $addrNew['post_code'] = $pickUpData['post_code'];
                $addrNew['type'] = 'pickup';
                if(isset($pickUpData['latitude'])){
                    $addrNew['latitude'] = $pickUpData['latitude'];
                }
                if(isset($pickUpData['longitude'])){
                    $addrNew['longitude'] = $pickUpData['longitude'];
                }
                AddressList::create($addrNew);
            }
            if(!$adr2){
                $addrNew = array();
                $addrNew['address'] = $dropOffData['address'];
                $addrNew['type'] = 'dropoff';
                if(isset($dropOffData['latitude'])){
                    $addrNew['latitude'] = $dropOffData['latitude'];
                }
                if(isset($dropOffData['longitude'])){
                    $addrNew['longitude'] = $dropOffData['longitude'];
                }
                AddressList::create($addrNew);
            }

            if($postData['is_delivery'] == 1 && count($delivery_products)){
                foreach($delivery_products as $delivery_product){
                    $delivery_product['booking_id'] = $data->id;

                    $delProduct = BookingDeliveryProducts::create($delivery_product);

                    if($delProduct){
                        $str = 'BD'.str_pad($delProduct->id, 5, "0", STR_PAD_LEFT);
                        BookingDeliveryProducts::where('id',$delProduct->id)->update(array('item_id'=>$str));
                    }
                }
            }
            if(count($products)){
                foreach($products as $product){
                    $product['booking_id'] = $data->id;

                    $prod = BookingProducts::create($product);

                    if($prod){
                        $str = 'BI'.str_pad($prod->id, 5, "0", STR_PAD_LEFT);
                        BookingProducts::where('id',$prod->id)->update(array('item_id'=>$str));
                    }
                }
            }

            $alt_phones1 = array();
            $alt_phones2 = array();
            if(count($pickUpData['alt_contact_nos'])){
                foreach($pickUpData['alt_contact_nos'] as $altNo){
                    $alt_phones1[] = $altNo['value'];
                }
            }
            if(count($dropOffData['alt_contact_nos'])){
                foreach($dropOffData['alt_contact_nos'] as $altNo){
                    $alt_phones2[] = $altNo['value'];
                }
            }

            $pickUpData['type'] = 'pickup';
            $pickUpData['alt_phones'] = serialize($alt_phones1);
            $pickUpData['booking_id'] = $data->id;
            $dropOffData['type'] = 'dropoff';
            $dropOffData['alt_phones'] = serialize($alt_phones2);
            $dropOffData['booking_id'] = $data->id;

            $pData = BookingUserDetails::create($pickUpData);
            $dData = BookingUserDetails::create($dropOffData);

            if($data->customer_id > 0){
                $addrNew = array();
                $addrNew['type'] = $dropOffData['type'];
                $addrNew['name'] = $dropOffData['name'];
                if(isset($dropOffData['email']))
                    $addrNew['email'] = $dropOffData['email'];
                $addrNew['phone'] = $dropOffData['phone'];
                $addrNew['alt_phones'] = serialize($dropOffData['alt_contact_nos']);
                $addrNew['address'] = $dropOffData['address'];
                $addrNew['customer_id'] = $data->customer_id;
                if(isset($dropOffData['latitude'])){
                    $addrNew['latitude'] = $dropOffData['latitude'];
                }
                if(isset($dropOffData['longitude'])){
                    $addrNew['longitude'] = $dropOffData['longitude'];
                }

                UserAdresses::create($addrNew);
            }
        }

        $data = Bookings::find($data->id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking added successfully.',
            'data' => $data
        ));
    }

    function getAddressList($type){
        $data = AddressList::select('address as label')->where('type',$type)->groupBy('address')->orderBy('address')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Address list got successfully.',
            'data' => $data
        ));
    }

    public function getBookingDetails($id){
        $data = Bookings::with('products')->with('pickup_details')->with('tracking_details')->where('reference_id',$id)->first();

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Booking details got successfully.',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'EROOR',
                'message' => 'Booking Id Not Found.'
            ));
        }

    }

    public function contactUs(Request $request){
        $postData = $request->all();

        Mail::to('info@agyakooshipping.co.uk')->send(new ContactUs($postData));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Form submitted successfully.'
        ));
    }
}
