<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Customer;
use App\Models\Bookings;
use DB;
use Validator;
use Laravel\Sanctum\PersonalAccessToken;
use Carbon\Carbon;

class UsersController extends Controller
{
    public function index(){
        $data = User::where('user_type','!=','Pickup Driver')->where('user_type','!=','GH Driver')->where('user_type','!=','Customer')->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Uesr list got successfully new',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['name'] = 'required';
        $rules['email'] = 'required|email|unique:users';
        $rules['phone'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $postData['status'] = 1;
        $postData['password'] = Hash::make($postData['password']);

        $data = User::create($postData);

        if($data){
            if($data->user_type == 'Customer'){
                $customerData['user_id'] = $data->id;
                $customerData['name'] = $postData['first_name'].' '.$postData['last_name'];
                $customerData['phone'] = $postData['phone'];
                $customerData['email'] = $postData['email'];
                $customerData['address'] = $postData['address'];
                $customerData['post_code'] = $postData['post_code'];
                if(!empty($postData['latitude']))
                    $customerData['latitude'] = $postData['latitude'];
                if(!empty($postData['longitude']))
                    $customerData['longitude'] = $postData['longitude'];

                $customer = Customer::create($customerData);

                $ids = str_pad($customer->id, 5, "0", STR_PAD_LEFT);
                Customer::where('id',$customer->id)->update(array('customer_id'=>'C'.$ids));

                $data['customer'] = Customer::find($customer->id);
            }


        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'User added successfully',
            'data' => $data
        ));
    }
 
    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $rules = array();
        $rules['name'] = 'required';
        $rules['email'] = 'required|email|unique:users,email,'.$id;

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        if(isset($postData['password'])){
            $postData['password'] = Hash::make($postData['password']);
        }

        User::where('id',$id)->update($postData);
        $data = User::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'User updated successfully',
            'data' => $data
        ));
    }
 
    public function show($id){
        $data = User::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'User details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();

        User::where('id', $id)->update($postData);
        $data = User::find($id);


        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'User updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = User::find($id);
        if($data){
            User::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'User deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }

    public function getDashboardData(){
        $data = array();

        $data['new_bookings'] = DB::table('bookings')->where('status',0)->get()->count();
        $data['total_bookings'] = DB::table('bookings')->where('status','!=',-1)->get()->count();
        $data['total_customers'] = DB::table('customers')->get()->count();
        $data['total_revenue'] = DB::table('bookings')->where('status','!=',-1)->get()->sum('total');
        $data['total_revenue'] = number_format($data['total_revenue'],2);

        $data['doughnut_data'] = array(0, 0, 0, 0, 0, 0,0,0);
        $data['doughnut_data'][0] = DB::table('bookings')->where('status',0)->get()->count();
        $data['doughnut_data'][1] = DB::table('bookings')->where('status',1)->get()->count();
        $data['doughnut_data'][2] = DB::table('bookings')->where('status',2)->get()->count();
        $data['doughnut_data'][3] = DB::table('bookings')->where('status',3)->get()->count();
        $data['doughnut_data'][4] = DB::table('bookings')->where('status',4)->get()->count();
        $data['doughnut_data'][5] = DB::table('bookings')->where('status',5)->get()->count();
        $data['doughnut_data'][6] = DB::table('bookings')->where('status',6)->get()->count();
        $data['doughnut_data'][7] = DB::table('bookings')->where('status',7)->get()->count();

        $data['bar_data'] = array('labels'=>[],'data'=> []);

        for($i=11; $i>=0; $i--){
            $data['bar_data']['labels'][] = date('M Y',strtotime('-'.$i.' months'));

            $data['bar_data']['data'][] = DB::table('bookings')->where('status','!=',-1)->whereYear('booking_date', Carbon::now()->subMonths($i)->year)->whereMonth('booking_date', Carbon::now()->subMonths($i)->month)->get()->sum('total');
        }

        $data['latest_bookings'] = Bookings::where('status','!=',-1)->orderByDesc('id')->limit(10)->get()->toArray();
     
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Dashboard data got successfully.',
            'data' => $data
        ));
    }

}
 