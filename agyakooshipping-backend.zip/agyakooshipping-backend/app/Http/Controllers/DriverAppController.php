<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use Auth;
use App\Models\Drivers;
use App\Models\Bookings;
use App\Models\BookingUserDetails;
use App\Models\BookingDrivers;
use App\Models\TrackBooking;
use Laravel\Sanctum\PersonalAccessToken;
use App\Models\BookingPaymentHistory;
use App\Models\Category;
use App\Models\Product;
use App\Models\BookingProducts;
use App\Models\Customer;
use App\Models\UserAdresses;
use App\Models\User;
use App\Models\BookingProductImage;
use App\Models\BookingDeliveryDrivers;
use App\Mail\ReceiptMail;
use Illuminate\Support\Facades\Mail;
use DB;
use Illuminate\Support\Facades\Hash;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use PDF;
use Illuminate\Support\Facades\Storage;
use App\Mail\OrderPickedUp;
use App\Mail\OrderDeliverred;

class DriverAppController extends Controller
{
    protected $driver;

    public function __construct(Request $request){
        $bearerToken = $request->bearerToken();
        $token = PersonalAccessToken::findToken($bearerToken);
        if($token){
            $user = $token->tokenable;
            $this->driver = Drivers::where('user_id',$user['id'])->first();
        }
    }

    public function login(Request $request){
        $postData = $request->all();


        $rules = array();
        $rules['email'] = 'required';
        $rules['password'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        if (Auth::guard()->attempt(array('email'=>$postData['email'],'password'=>$postData['password']))) {
            $user = Auth::user();
            if($user->status == 1){
                $token = $user->createToken($user->name,array('*'),now()->addHours(24))->plainTextToken;
                $user ->api_token = $token;
                $user->driverData = Drivers::where('user_id',$user->id)->first();

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Logged in successfully',
                    'data' => $user
                ));
            }else{
                return response()->json(array(
                    'status' => 'ERROR',
                    'message' => 'This user is inactive now. Please contact admin.'
                ));
            }
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Sorry, that username or password is incorrect. Please try again.'
            ));
        }
    }

    public function getTodayRequests(Request $request){
        //$data = Bookings::join('booking_drivers','booking_drivers.booking_id','=','bookings.id')->with('pickup_details')->where('booking_drivers.driver_id',$this->driver->id)->whereDate('bookings.pickup_date', now()->today())->orderByDesc('bookings.id')->select('bookings.*','booking_drivers.is_cancel as is_driver_cancel','booking_drivers.is_picked as is_driver_picked')->get()->toArray();

        $resQuery = Bookings::join('booking_drivers','booking_drivers.booking_id','=','bookings.id')->with('pickup_details');
        $resQuery = $resQuery->where('booking_drivers.driver_id',$this->driver->id);
        if(isset($request->start_date) && isset($request->end_date)){
            $resQuery = $resQuery->whereBetween('bookings.pickup_date', [$request->start_date, $request->end_date]);
        }
        $data = $resQuery->orderByDesc('bookings.id')->select('bookings.*','booking_drivers.is_cancel as is_driver_cancel','booking_drivers.is_picked as is_driver_picked')->get()->toArray();
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getRequests(Request $request){
        /*$data = Bookings::join('booking_drivers','booking_drivers.booking_id','=','bookings.id')->with('pickup_details')->where('booking_drivers.driver_id',$this->driver->id)->where(function ($query) {
            $query->where('booking_drivers.is_picked', 1)->orWhere('booking_drivers.is_cancel', 1);
        })->orderByDesc('pickup_date')->select('bookings.*','booking_drivers.is_cancel as is_driver_cancel','booking_drivers.is_picked as is_driver_picked')->get()->toArray();*/

        $resQuery = Bookings::join('booking_drivers','booking_drivers.booking_id','=','bookings.id')->with('pickup_details');
        $resQuery = $resQuery->where('booking_drivers.driver_id',$this->driver->id);

        if(isset($request->start_date) && isset($request->end_date)){
            $resQuery = $resQuery->whereBetween('bookings.pickup_date', [$request->start_date, $request->end_date]);
        }

        $data = $resQuery->orderByDesc('pickup_date')->select('bookings.*','booking_drivers.is_cancel as is_driver_cancel','booking_drivers.is_picked as is_driver_picked')->get()->toArray();;
        
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getRequestDetails($id){
        $data = Bookings::with('pickup_details')->with('dropoff_details')->with('customer')->with('products')->where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getAddressDetails($id){
        $data = BookingUserDetails::where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Address got successfully.',
            'data' => $data
        ));
    }

    public function updateAddressDetails(Request $request, $id){
        $postData = $request->all();

        if(count($postData)){
            foreach($postData as $key=>$val){
                if(empty($val)){
                    $postData[$key] = '';
                }
            }
        }

        BookingUserDetails::where('id',$id)->update($postData);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Address update successfully.',
        ));
    }

    public function cancelBookings(Request $request,$id){
        Bookings::where('id',$id)->update(array('status'=>0));
        BookingDrivers::where('driver_id',$this->driver->id)->where('booking_id',$id)->update(array('is_cancel'=>1,'pickup_date'=> date('Y-m-d')));
        TrackBooking::where('booking_id',$id)->where('status',1)->delete();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver unassigned successfully.',
        ));
    }

    public function bookingItemDetails($id){
        $data = Bookings::with('products')->where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function bookingPickedUp(Request $request){
        $postData = $request->all();

        $bookingId = $postData['bookingId'];

        Bookings::where('id',$bookingId)->update(array('status'=>2, 'pickup_date'=>date('Y-m-d')));
        BookingDrivers::where('driver_id',$this->driver->id)->where('booking_id',$bookingId)->update(array('is_picked'=>1,'pickup_date'=> date('Y-m-d')));
        BookingProducts::where('booking_id',$bookingId)->update(array('is_loaded'=>1));
        TrackBooking::create(array('status'=>2,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));

        if(floatval($postData['paymentAmount']) > 0){
            $bData = DB::table('bookings')->where('id',$bookingId)->select('total','paid_amount')->first();
            $balance = floatval($bData->total)-floatval($bData->paid_amount);
            $payment_status = 0;
            if(($balance - floatval($postData['paymentAmount'])) <= 0){
                $payment_status = 1;
            }
            Bookings::where('id',$bookingId)->update(array('paid_amount'=>floatval($postData['paymentAmount']), 'payment_status'=>$payment_status));
            BookingPaymentHistory::create(array('added_by'=>0,'amount'=>floatval($postData['paymentAmount']),'note'=>@$postData['paymentNote'],'payment_method'=>@$postData['payment_method'],'booking_id'=>$bookingId));
        }

        $mailData = Bookings::with('pickup_details')->with('dropoff_details')->with('picked_driver')->with('products')->find($bookingId);

        $sendTo = array($mailData['pickup_details']['email'], 'info@agyakooshipping.co.uk');
        Mail::to($sendTo)->send(new OrderPickedUp($mailData));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Item picked up successfully.',
        ));
    }

    public function getProductList(){
        $data = Product::where('status',1)->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery Category list got successfully.',
            'data' => $data
        ));
    }

    public function updateItems(Request $request){
        $allData = $request->all();
        $products = $allData['products'];

        Bookings::where('id',$allData['booking_id'])->update(array('no_of_items'=>$allData['no_of_items'],'amount'=>$allData['amount'],'total'=>$allData['total']));

        BookingProducts::where('booking_id',$allData['booking_id'])->delete();

        if(count($products)){
            foreach($products as $product){
                if($product['category_id'] == 999){
                    $productId = 0;
                    $productTitle = $product['item_id'];
                }else{
                    $productId = $product['item_id'];
                    $productTitle = Product::where('id',$product['item_id'])->pluck('title')->first();
                }
                $isFragile = $product['is_fragile'] ? 1:0;
                $prod = BookingProducts::create(array('product_id'=>$productId,'product_title'=>$productTitle,'is_fragile'=>$isFragile,'price'=>$product['total'],'sub_amount'=>$product['total'],'quantity'=>1, 'booking_id'=>$allData['booking_id']));

                if($prod){
                    $str = 'BI'.str_pad($prod->id, 5, "0", STR_PAD_LEFT);
                    BookingProducts::where('id',$prod->id)->update(array('item_id'=>$str));
                }
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Item updated successfully.'
        ));
    }

    public function getCustomerDDList(){
        $data = Customer::select('*','id as value',DB::raw("CONCAT(name,' - ',address)  AS label"))->where('is_deleted',0)->orderBy('name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer list got successfully.',
            'data' => $data
        ));
    }

    public function getUserAddresses($user_id,$type){
        $primaryData = array();
        if($type == 'pickup'){
            $primaryData = Customer::where('id',$user_id)->select(DB::raw('0 as value'),DB::raw("CONCAT(name,' - ',address)  AS label"),'name','email','phone','alt_phones','address','post_code')->get()->toArray();
        }
        $data = UserAdresses::select('id as value',DB::raw("CONCAT(name,' - ',address)  AS label"),'name','email','phone','alt_phones','address','post_code')->where('customer_id',$user_id)->where('type',$type)->orderBy('name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'User address list got successfully.',
            'data' => array_merge($primaryData,$data)
        ));
    }

    public function addBooking(Request $request){
        $postData = $request->all();

        $products = array();
        $dropOffData = array();
        $pickUpData = array();

        if(isset($postData['products'])){
            $products = $postData['products'];
            unset($postData['products']);
        }

        if(isset($postData['dropOffData'])){
            $dropOffData = $postData['dropOffData'];
            unset($postData['dropOffData']);
        }

        if(isset($postData['pickUpData'])){
            $pickUpData = $postData['pickUpData'];
            unset($postData['pickUpData']);
        }
        if(empty($postData['company_name'])){
            unset($postData['company_name']);
        }

        $postData['pickup_date'] = date('Y-m-d');
        $postData['booking_date'] = date('Y-m-d');
        $postData['estimated_delivery_date'] = date('Y-m-d',strtotime("+15 days", strtotime($postData['pickup_date'])));
        $postData['added_by'] = $this->driver->user_id;

        $data = Bookings::create($postData);

        if($data){
            TrackBooking::create(array('status'=>0,'datetime'=>$data->created_at,'booking_id'=>$data->id));
            $str = 'B'.str_pad($data->id, 6, "0", STR_PAD_LEFT);
            Bookings::where('id',$data->id)->update(array('reference_id'=>$str,'customer_type'=>'Registered'));

            if(count($products)){
                foreach($products as $product){
                    $product['booking_id'] = $data->id;

                    $prod = BookingProducts::create($product);

                    if($prod){
                        $str = 'BI'.str_pad($prod->id, 5, "0", STR_PAD_LEFT);
                        BookingProducts::where('id',$prod->id)->update(array('item_id'=>$str));
                    }
                }
            }

            BookingUserDetails::create(array('type'=>'pickup','name'=>$pickUpData['name'],'email'=>$pickUpData['email'],'phone'=>$pickUpData['phone'],'address'=>$pickUpData['address'],'post_code'=>$pickUpData['post_code'],'booking_id'=>$data->id,'alt_phones'=>serialize(array())));

            $dOfData = array('type'=>'dropoff','name'=>$dropOffData['name'],'phone'=>$dropOffData['phone'],'address'=>$dropOffData['address'],'booking_id'=>$data->id,'alt_phones'=>serialize(array()));
            if(!empty($dropOffData['email'])){
                $dOfData['email'] = $dropOffData['email'];
            }

            BookingUserDetails::create($dOfData);

            if($pickUpData['addr'] == -1){
                UserAdresses::create(array('type'=>'pickup','name'=>$pickUpData['name'],'email'=>$pickUpData['email'],'phone'=>$pickUpData['phone'],'alt_phones'=>serialize(array()),'address'=>$pickUpData['address'],'post_code'=>$pickUpData['post_code'],'customer_id'=>$data->customer_id));
            }
            if($dropOffData['addr'] == -1){
                $dOfData = array('type'=>'dropoff','name'=>$dropOffData['name'],'phone'=>$dropOffData['phone'],'alt_phones'=>serialize(array()),'address'=>$dropOffData['address'],'customer_id'=>$data->customer_id);
                if(!empty($dropOffData['email'])){
                    $dOfData['email'] = $dropOffData['email'];
                }
                UserAdresses::create($dOfData);
            }

            if($data->paid_amount > 0){
                BookingPaymentHistory::create(array('added_by'=>$this->driver->user_id,'amount'=>$data->paid_amount ,'note'=>@$postData['paymentNote'],'booking_id'=>$data->id,'payment_method'=>@$postData['payment_method']));
            }

            BookingDrivers::create(array('booking_id'=>$data->id,'driver_id'=>$this->driver->id,'is_picked'=>1,'pickup_date'=>date('Y-m-d')));
            TrackBooking::create(array('status'=>1,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$data->id));

            Bookings::where('id',$data->id)->update(array('status'=>2));
            TrackBooking::create(array('status'=>2,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$data->id));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking added successfully.',
            'data' => $data
        ));
    }

    public function addCustomer(Request $request){
        $postData = $request->all();

        $phone = '';
        if(!empty($postData['phone'])){
            $phone = '+44'.$postData['phone'];
        }

        $userData['name'] = $postData['name'];
        $userData['email'] = $postData['email'];
        $userData['phone'] = $phone;
        $userData['password'] = Hash::make('123456');
        $userData['user_type'] = 'Customer';
        $userData['status'] = 1;

        $data = User::create($userData);

        if($data){
            $postData['user_id'] = $data->id;
            $postData['alt_phones'] = serialize(array());

            $customer = Customer::create($postData);
            if($customer){
                $str = 'C'.str_pad($customer->id, 5, "0", STR_PAD_LEFT);
                Customer::where('id',$customer->id)->update(array('customer_id'=>$str));
                $customerData = Customer::where('id',$customer->id)->first()->toArray();

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Customer list got successfully.',
                    'data' => $customerData
                ));
            }
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.'
        ));
    }

    public function uploadImage(Request $request){
        if($request->hasFile('image')){
            $rules=array(
                'image' => 'required|mimes:png,jpg,jpeg'
            );

            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $new_name = $this->createToken3(15).time() . '.'.$extension;

            $file->storeAs('public/',$new_name);

            BookingProductImage::create(array('image'=>$new_name, 'booking_id'=>$request->booking_id, 'booking_product_id'=>$request->booking_product_id));

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Image upload successfully.'
            ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.'
        ));
    }

    public function uploadImages(Request $request){
        if($request->hasFile('images')){
            $files = $request->file('images');

            if(count($files)){
                foreach($files as $file){
                    $extension = $file->getClientOriginalExtension();
                    $new_name = $this->createToken3(15).time() . '.'.$extension;
                    $file->storeAs('public/',$new_name);

                    BookingProductImage::create(array('image'=>$new_name, 'booking_id'=>$request->booking_id, 'booking_product_id'=>$request->booking_product_id));
                }
            }

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Image upload successfully.'
            ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.'
        ));
    }

    function createToken3($length=6){
        $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $result = substr(str_shuffle($permitted_chars), 0, $length);

        return $result;
    }

    public function sendEmail($id){
        $data = Bookings::with('pickup_details')->with('dropoff_details')->with('products')->with('customer')->where('id',$id)->first();

        $customerMail = @$data['pickup_details']['email'];
        
        //Mail::to($customerMail)->cc('eakosahe@yahoo.com')->bcc('vtiontech@gmail.com')->send(new ReceiptMail($data));

        $pHtml = '';
        if(count($data['products'])){
            foreach ($data['products'] as $item){
                $pHtml .= "<tr><td style='padding:3px;'>".$item['item_id']."</td><td style='padding:3px;'>".$item['product_title_new']."</td><td style='padding: 3px; text-align: right;'>£".number_format($item['sub_amount'],2)."</td></tr>";
            }
        }

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'https://api.brevo.com/v3/smtp/email');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"sender\":{\"name\":\"Admin\",\"email\":\"admin@agyakooshipping.com\"},\"to\":[{\"email\":\"".$customerMail."\"}],\"cc\":[{\"email\":\"eakosahe@yahoo.com\"}],\"bcc\":[{\"email\":\"vtiontech@gmail.com\"}],\"subject\":\"Agyakoo Shipping: Order Receipt\",\"htmlContent\":\"<div style='max-width: 600px; width: 600px; margin: 0 auto; background: #fff; border-radius: 5px; padding-bottom: 28px; font-family: Roboto, sans-serif;'><table style='width: 500px; border-bottom: 1px solid #000;'><tr><td colspan='2'><p style='font-weight: bold; color: #008000; text-align: center; font-size: 28px; margin: 0; padding-bottom: 15px;'>Order Receipt</p><p style='font-weight: bold; color: #000066; text-align: center; font-size: 16px; margin: 0; padding-bottom: 30px;'>Thank you for your order!</p></td></tr><tr><td>&nbsp;</td><td style='padding:10px 3px; text-align: right;'><div style='font-size: 14px; font-weight: 800;'>Agyakoo Shipping Ltd.</div><div style='font-size: 13px; font-weight: 600;'>31 Waleys Close, Luton, Lu3 3rz</div></td></tr></table><table style='width: 500px; border-bottom: 1px solid #000;'><tr><td>&nbsp;</td><td style='padding:10px 3px; text-align: right;'><div style='font-size: 13px; font-weight: 600;'>Tel : +44 7853 607006</div></td></tr></table><table style='width: 500px;' cellspacing='0'><tr><td style='padding: 10px 3px 5px; font-size: 13px; font-weight: 600; border-bottom: 1px solid #000;'>Customer Details</td><td style='border-bottom: 1px solid #000;'>&nbsp;</td></tr><tr><td style='padding: 10px 3px;'><div style='font-size: 12px;'><span style='font-weight: 700;'>ID:</span> ".$data['customer']['customer_id']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Name:</span> ".$data['customer']['name']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Phone:</span> ".$data['customer']['phone']."</div></td><td style='padding:10px 3px; text-align: right;'><div style='font-size: 12px;'><span style='font-weight: 700;'>Booking ID:</span> ".$data['reference_id']."</div></td></tr></table><table style='width: 500px;' cellspacing='0'><tr><td style='padding: 10px 3px 5px; font-size: 13px; font-weight: 600; border-bottom: 1px solid #000;'>Pick Up Address</td><td style='padding: 10px 3px 5px; font-size: 13px; font-weight: 600; border-bottom: 1px solid #000;'>Recepient Addres</td></tr><tr style='border-bottom: 1px solid #000;'><td style='padding: 10px 3px;'><div style='font-size: 12px;'><span style='font-weight: 700;'>Name:</span> ".$data['pickup_details']['name']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Address:</span> ".$data['pickup_details']['address']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Phone:</span> ".$data['pickup_details']['phone']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Postcode:</span> ".$data['pickup_details']['post_code']."</div></td><td style='font-size: 12px;'><div style='font-size: 12px;'><span style='font-weight: 700;'>Name:</span> ".$data['dropoff_details']['name']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Address:</span> ".$data['dropoff_details']['address']."</div><div style='font-size: 12px;'><span style='font-weight: 700;'>Phone:</span> ".$data['dropoff_details']['phone']."</div></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr></table><table style='width: 500px;' cellspacing='0'><tr><td style='font-size: 13px; font-weight: 600; padding: 10px 3px 5px; border-bottom: 1px solid #000;'>Pickup ID</td><td style='font-size: 13px; font-weight: 600; padding: 10px 3px 5px; border-bottom: 1px solid #000;'>Pickup Item</td><td style='font-size: 13px; font-weight: 600; padding: 10px 3px 5px; text-align: center; border-bottom: 1px solid #000;'>Price</td></tr>".$pHtml."<tr><td style='padding:3px; border-top: 1px solid #000;'>&nbsp;</td><td style='font-size: 13px; font-weight: 600; padding: 3px; text-align: right; border-top: 1px solid #000;'>Sub Total</td><td style='padding: 3px; text-align: right; border-top: 1px solid #000;'>£".number_format($data['amount'],2)."</td></tr><tr><td style='padding:3px;'>&nbsp;</td><td style='font-size: 13px; font-weight: 600; padding: 3px; text-align: right;'>Discount</td><td style='padding: 3px; text-align: right;'>£00.00</td></tr><tr><td style='padding:3px;'>&nbsp;</td><td style='font-size: 13px; font-weight: 600; padding: 3px; text-align: right;'>Tax</td><td style='padding: 3px; text-align: right;'>£00.00</td></tr><tr><td style='padding:3px; border-bottom: 1px solid #000;'>&nbsp;</td><td style='font-size: 14px; font-weight: 700; padding: 3px; text-align:right; border-bottom: 1px solid #000;'>Total</td><td style='padding: 3px; text-align: right; border-bottom: 1px solid #000;'>£".number_format($data['total'],2)."</td></tr></table></div>\"}");

        $headers = array();
        $headers[] = 'Accept: application/json';
        $headers[] = 'Api-Key: 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';
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
            return curl_error($ch);
        }
        curl_close($ch);

        return response()->json(array(
            'status' => 'SUCCESS',
            'data'=>$data
        ));
    }

    public function getQRList($id){
        $data = array();

        $bookData = Bookings::with('pickup_details')->with('dropoff_details')->with('products')->where('id',$id)->first();

        if($bookData){
            if(count($bookData['products'])){
                foreach($bookData['products'] as $product){
                    $arr = array();
                    $arr['product_id'] = $product['id'];
                    $arr['p_id'] = $product['item_id'];
                    $arr['p_title'] = $product['product_title_new'];
                    $arr['p_price'] = $product['sub_amount'];
                    $arr['r_name'] = $bookData['dropoff_details']['name'];
                    $arr['r_address'] = $bookData['dropoff_details']['address'];
                    $arr['r_phone'] = $bookData['dropoff_details']['phone'];

                    //$arr['qrsrc'] = base64_decode(base64_encode(QrCode::size(220)->generate(base64_encode(base64_encode('AgyakooShipping-'.$product['booking_id'].'-'.$product['id'])))));
                    $arr['qrsrc'] = base64_encode(base64_encode('AgyakooShipping-'.$product['booking_id'].'-'.$product['id']));
                    $arr['image_url'] = '';
                    if(count($product['images'])){
                        $ind = count($product['images']);
                        $ind = $ind-1;
                        $arr['image_url'] = $product['images'][$ind]['image_url'];
                    }

                    $data[] = $arr;
                }
            }
        }


        return response()->json(array(
            'status' => 'SUCCESS',
            'data'=>$data
        ));
    }

    public function downloadQRPdf($id){
        $filename1 = 'QR-' .$this->createToken3(15).'-'.time() . '.pdf';
        $filename = public_path('pdf/'.$filename1);

        $customPaper = array(0,0,500.00,320.00);
        $data = BookingProducts::with('booking')->with('recepient_data')->where('booking_id',$id)->orderBy('id')->get()->toArray();

        $pdf = PDF::loadView('pdf/booking_items_qr', array('data'=>$data))->setPaper($customPaper, 'landscape')->save($filename);

        return response()->json(array(
            'status' => 'SUCCESS',
            'data'=> 'https://backend.agyakooshipping.com/public/pdf/'.$filename1
        ));

    }

    public function downloadReceipt($id){
        $filename1 = 'QR-' .$this->createToken3(15).'-'.time() . '.pdf';
        $filename = public_path('pdf/'.$filename1);

        $customPaper = array(0,0,750.00,320.00);
        $data = Bookings::with('pickup_details')->with('dropoff_details')->with('products')->with('customer')->where('id',$id)->first();

        $pdf = PDF::loadView('pdf/booking_receipt', array('data'=>$data))->setPaper($customPaper, 'landscape')->save($filename);
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'data'=> 'https://backend.agyakooshipping.com/public/pdf/'.$filename1
        ));
    }

    public function getProductListNew(){
        $data = Product::with('children')->where('status',1)->where('parent_id',0)->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery Category list got successfully.',
            'data' => $data
        ));
    }


    public function getDeliveryRequests(Request $request){
        $resQuery = Bookings::join('booking_delivery_drivers','booking_delivery_drivers.booking_id','=','bookings.id')->with('dropoff_details');
        $resQuery = $resQuery->where('booking_delivery_drivers.driver_id',$this->driver->id);

        if(isset($request->start_date) && isset($request->end_date)){
            $resQuery = $resQuery->whereBetween('booking_delivery_drivers.delivered_date', [$request->start_date, $request->end_date]);
        }

        $data = $resQuery->orderByDesc('delivered_date')->select('bookings.*','booking_delivery_drivers.is_failed as is_driver_failed','booking_delivery_drivers.is_deliverred as is_driver_deliverred')->get()->toArray();;
        
        
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getDeliveryRequestDetails($id){
        $data = Bookings::with('pickup_details')->with('dropoff_details')->with('customer')->with('products')->where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function bookingDeliveryItemDetails($id){
        $data = Bookings::with('products')->where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function bookingDeliverred(Request $request){
        $postData = $request->all();

        $bookingId = $postData['bookingId'];

        BookingDeliveryDrivers::where('booking_id',$bookingId)->where('driver_id',$this->driver->id)->where('is_failed',0)->update(array('is_deliverred'=>1,'delivered_date'=>date('Y-m-d')));

        BookingProducts::where('booking_id',$bookingId)->update(array('is_deliverred'=>1, 'delivered_date'=>date('Y-m-d H:i:s')));
        Bookings::where('id',$bookingId)->update(array('status'=>7, 'estimated_delivery_date'=>date('Y-m-d H:i:s')));

        TrackBooking::create(array('status'=>7,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));

        if(isset($postData['delivery_note'])){
            Bookings::where('id',$bookingId)->update(array('delivery_note'=>$postData['delivery_note']));
        }

        if($request->hasFile('signature')){
            $rules=array(
                'image' => 'required|mimes:png,jpg,jpeg'
            );

            $file = $request->file('signature');
            $extension = $file->getClientOriginalExtension();
            $new_name = $this->createToken3(15).time() . '.'.$extension;

            $file->storeAs('public/',$new_name);

            Bookings::where('id',$bookingId)->update(array('customer_signature'=>$new_name));
        }

        $mailData = Bookings::with('pickup_details')->with('dropoff_details')->with('picked_driver')->with('delivery_driver')->with('products')->find($bookingId);

        $sendTo = array($mailData['pickup_details']['email'], 'info@agyakooshipping.co.uk');
        Mail::to($sendTo)->send(new OrderDeliverred($mailData));


        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Item deliverred successfully.'
        ));
    }

    public function uploadDeliveryImage(Request $request){
        if($request->hasFile('image')){
            $rules=array(
                'image' => 'required|mimes:png,jpg,jpeg'
            );

            $file = $request->file('image');
            $extension = $file->getClientOriginalExtension();
            $new_name = $this->createToken3(15).time() . '.'.$extension;

            $file->storeAs('public/',$new_name);

            BookingProductImage::create(array('image'=>$new_name, 'booking_id'=>$request->booking_id, 'booking_product_id'=>$request->booking_product_id,'is_delivery'=>1));

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Image upload successfully.'
            ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.'
        ));
    }

    public function uploadDeliveryImages(Request $request){
        if($request->hasFile('images')){
            $files = $request->file('images');

            if(count($files)){
                foreach($files as $file){
                    $extension = $file->getClientOriginalExtension();
                    $new_name = $this->createToken3(15).time() . '.'.$extension;
                    $file->storeAs('public/',$new_name);

                    BookingProductImage::create(array('image'=>$new_name, 'booking_id'=>$request->booking_id, 'booking_product_id'=>$request->booking_product_id,'is_delivery'=>1));
                }
            }

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Image upload successfully.'
            ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.'
        ));
    }


}
