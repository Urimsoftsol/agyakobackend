<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Customer;
use App\Models\CustomerMembership;
use DB;
use Validator;
use Laravel\Sanctum\PersonalAccessToken;

class CustomerController extends Controller
{
    public function index(){
        $data = Customer::where('is_deleted',0)->orderByDesc('id')->get()->toArray();

        // $subQuery1= DB::table('customer_memberships')->select('customer_memberships.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');

        // $data = Bookings::with('products')->with('pickup_details')->with('dropoff_details')->joinSub($subQuery1, 'subQuery1', function ($join) {
        //     $join->on('subQuery1.booking_id', '=', 'bookings.id');
        // })->leftJoinSub($subQuery2, 'subQuery2', function ($join) {
        //     $join->on('subQuery2.booking_id', '=', 'bookings.id');
        // })->leftJoinSub($subQuery3, 'subQuery3', function ($join) {
        //     $join->on('subQuery3.booking_id', '=', 'bookings.id');
        // })->select('id','reference_id',DB::Raw('IFNULL( subQuery1.total , 0 ) as no_of_item'),DB::Raw('IFNULL( subQuery2.total , 0 ) as no_of_item2'),DB::Raw('IFNULL( subQuery3.total , 0 ) as no_of_item3'))->having('no_of_item2', '>', 0)->get()->toArray();






        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer list got successfully.',
            'data' => $data
        ));
    }
    public function index1(){
        $data = Customer::where('is_deleted',0)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer list got successfully.',
            'data' => $data
        ));
    }
    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['name'] = 'required';
        $rules['email'] = 'required|email|unique:users';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $userData['name'] = $postData['name'];
        $userData['email'] = $postData['email'];
        $userData['phone'] = $postData['phone'];
        $userData['password'] = Hash::make('123456');
        $userData['user_type'] = 'Customer';
        $userData['status'] = 1;

        $data = User::create($userData);

        if($data){
            $driverData['user_id'] = $data->id;
            $driverData['name'] = $postData['name'];
            $driverData['email'] = $postData['email'];
            $driverData['phone'] = $postData['phone'];
            $driverData['alt_phones'] = serialize(array());
            $driverData['address'] = $postData['address'];
            $driverData['post_code'] = $postData['post_code'];
            $driverData['registered_company'] = $postData['registered_company'];
            if($postData['registered_company'] == 'Yes'){
                $driverData['company_name'] = $postData['company_name'];
                $driverData['company_shipping'] = $postData['company_shipping'];
            }
            if(isset($postData['latitude'])){
                $driverData['latitude'] = $postData['latitude'];
            }
            if(isset($postData['longitude'])){
                $driverData['longitude'] = $postData['longitude'];
            }
            $driverData['status'] = 1;

            $driver = Customer::create($driverData);

            $ids = str_pad($driver->id, 5, "0", STR_PAD_LEFT);
            Customer::where('id',$driver->id)->update(array('customer_id'=>'C'.$ids));

            $data = Customer::find($driver->id);
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer added successfully',
            'data' => $data
        ));
    }

    public function show($id){
        $data = Customer::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Driver details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $driverData['name'] = $postData['name'];
        $driverData['email'] = $postData['email'];
        $driverData['phone'] = $postData['phone'];
        $driverData['address'] = $postData['address'];
        $driverData['post_code'] = $postData['post_code'];
        $driverData['registered_company'] = $postData['registered_company'];
        if($postData['registered_company'] == 'Yes'){
            $driverData['company_name'] = $postData['company_name'];
            $driverData['company_shipping'] = $postData['company_shipping'];
        }
        if(isset($postData['latitude'])){
            $driverData['latitude'] = $postData['latitude'];
        }
        if(isset($postData['longitude'])){
            $driverData['longitude'] = $postData['longitude'];
        }

        Customer::where('id',$id)->update($driverData);
        $data = Customer::find($id);

        User::where('id',$data->user_id)->update(array('name'=>$postData['name'],'email'=>$postData['email'],'phone'=>$postData['phone']));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer updated successfully',
            'data' => $data
        ));
    }

    public function update(Request $request, $id){
        $postData = $request->all();

        Customer::where('id', $id)->update($postData);
        $data = Customer::find($id);
        if(isset($postData['status'])){
            User::where('id',$data->user_id)->update(array('status'=>$postData['status']));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Customer::find($id);
        if($data){
            Customer::where('id', $id)->update(array('is_deleted'=>1));
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Customer deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }
    public function addMembership(Request $request){
       $postData = $request->all();
        $rules = array();
        $rules['membership_id'] = 'required';
        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $membershipData['customer_id'] = $postData['customer_id'];
        $membershipData['membership_id'] = $postData['membership_id'];
        $membershipData['starting_date'] = date('Y-m-d');
        $membershipData['purchase_date'] =  date('Y-m-d');
        $membershipData['expired_date'] = date('Y-m-d H:i:s', strtotime("+".$postData['duration'], strtotime(date('Y-m-d H:i:s')))) ;
        $membershipData['status'] = 1;

        $data = CustomerMembership::create($membershipData);

     
        

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Membership added successfully',
            'data' => $membershipData
        ));   
    }
    
}
