<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Delivery_product;
use DB;
use Validator;
class DeliveryProductController extends Controller
{
    public function index(){
        $data = Delivery_product::orderBy('parent_id')->get()->toArray();
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery Product list got successfully',
            'data' => $data
        ));
    }
    public function categoryList(){
        $data = Delivery_product::where('parent_id',0)->where('status',1)->select('id as value','title as label')->orderBy('title')->get()->toArray();
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery Category list got successfully',
            'data' => $data
        ));    
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $postData['status'] = 1;

        $data = Delivery_product::create($postData);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery product added successfully',
            'data' => $data
        ));
    }
 
    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';


        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }
        Delivery_product::where('id',$id)->update($postData);
        $data = Delivery_product::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery product updated successfully',
            'data' => $data
        ));
    }
 
    public function show($id){
        $data = Delivery_product::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Delivery product details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();

        Delivery_product::where('id', $id)->update($postData);
        $data = Delivery_product::find($id);


        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery product updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Delivery_product::find($id);
        if($data){
            Delivery_product::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Delivery product deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    } 
}
