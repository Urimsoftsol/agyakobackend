<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ShippingContainer;
use Validator;

class ShippingContainerController extends Controller
{
    public function index(){
        $data = ShippingContainer::where('is_deleted',0)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Container list got successfully.',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['container_no'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $postData['status'] = 1;

        $data = ShippingContainer::create($postData);
        /*if($data){
            $str = 'CO'.str_pad($data->id, 3, "0", STR_PAD_LEFT);
            ShippingContainer::where('id',$data->id)->update(array('seal_ref_no'=>$str));
            $data = ShippingContainer::find($data->id);
        }*/

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Container added successfully',
            'data' => $data
        ));
    }

    public function show($id){
        $data = ShippingContainer::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Container details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();

        ShippingContainer::where('id', $id)->update($postData);
        $data = ShippingContainer::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Container updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = ShippingContainer::find($id);
        if($data){
            ShippingContainer::where('id', $id)->update(array('is_deleted'=>1));
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Container deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }
}
