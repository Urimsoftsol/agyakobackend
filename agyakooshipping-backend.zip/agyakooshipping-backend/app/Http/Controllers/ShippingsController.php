<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shippings;
use App\Models\Bookings;
use App\Models\BookingProducts;
use App\Models\TrackBooking;
use Validator;
use DB;
use PDF;
use Illuminate\Support\Facades\Mail;
use App\Mail\OrderShipped;

class ShippingsController extends Controller
{
    public function index(){
        $data = Shippings::orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shipping list got successfully.',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $postData['status'] = 0;

        $data = Shippings::create($postData);
        if($data){
            $str = 'S'.str_pad($data->id, 6, "0", STR_PAD_LEFT);
            Shippings::where('id',$data->id)->update(array('reference_id'=>$str));

            BookingProducts::where('container_id',$data->container_no)->where('is_shipped',0)->update(array('shipping_id'=>$data->id));

            /*$bookingIds = BookingProducts::where('container_id',$data->container_no)->where('is_shipped',0)->pluck('booking_id')->toArray();
            Bookings::whereIn('id',$bookingIds)->update(array('status'=>4,'shipping_id'=>$data->id));
            BookingProducts::where('container_id',$data->container_no)->where('is_shipped',0)->update(array('is_shipped'=>1,'shipping_id'=>$data->id));
            
            if(count($bookingIds)){
                foreach($bookingIds as $bookingId){
                    TrackBooking::create(array('status'=>4,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));
                }
            }*/
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shipping added successfully',
            'data' => $data
        ));
    }

    public function updateAll(Request $request, $id){
        $postData = $request->all();

        Shippings::where('id',$id)->update($postData);
        $data = Shippings::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shipping updated successfully',
            'data' => $data
        ));
    }

    public function show($id){
        $data = Shippings::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Shipping details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();

        Shippings::where('id', $id)->update($postData);
        $data = Shippings::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shipping updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Shippings::find($id);
        if($data){
            Shippings::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Shipping deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }

    public function getBookingListWh(){
        $subQuery1= DB::table('booking_products')->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');
        $subQuery2= DB::table('booking_products')->where('is_wh_received',1)->where('is_container_loaded',0)->where('is_shipped',0)->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');
        $subQuery3= DB::table('booking_products')->where('is_wh_received',1)->where('is_container_loaded',1)->where('is_shipped',0)->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');

        $data = Bookings::with('products')->with('pickup_details')->with('dropoff_details')->joinSub($subQuery1, 'subQuery1', function ($join) {
            $join->on('subQuery1.booking_id', '=', 'bookings.id');
        })->leftJoinSub($subQuery2, 'subQuery2', function ($join) {
            $join->on('subQuery2.booking_id', '=', 'bookings.id');
        })->leftJoinSub($subQuery3, 'subQuery3', function ($join) {
            $join->on('subQuery3.booking_id', '=', 'bookings.id');
        })->select('id','reference_id',DB::Raw('IFNULL( subQuery1.total , 0 ) as no_of_item'),DB::Raw('IFNULL( subQuery2.total , 0 ) as no_of_item2'),DB::Raw('IFNULL( subQuery3.total , 0 ) as no_of_item3'))->having('no_of_item2', '>', 0)->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getBookingListCon($container_id){
        $subQuery1= DB::table('booking_products')->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');
        $subQuery2= DB::table('booking_products')->where('is_wh_received',1)->where('is_container_loaded',0)->where('is_shipped',0)->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');
        $subQuery3= DB::table('booking_products')->where('is_wh_received',1)->where('is_container_loaded',1)->where('is_ship_received',0)->where('container_id',$container_id)->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');

        $data = Bookings::with('products')->with('pickup_details')->with('dropoff_details')->joinSub($subQuery1, 'subQuery1', function ($join) {
            $join->on('subQuery1.booking_id', '=', 'bookings.id');
        })->leftJoinSub($subQuery2, 'subQuery2', function ($join) {
            $join->on('subQuery2.booking_id', '=', 'bookings.id');
        })->leftJoinSub($subQuery3, 'subQuery3', function ($join) {
            $join->on('subQuery3.booking_id', '=', 'bookings.id');
        })->select('id','reference_id',DB::Raw('IFNULL( subQuery1.total , 0 ) as no_of_item'),DB::Raw('IFNULL( subQuery2.total , 0 ) as no_of_item2'),DB::Raw('IFNULL( subQuery3.total , 0 ) as no_of_item3'))->having('no_of_item3', '>', 0)->get()->toArray();

        if(count($data)){
            foreach($data as $key=>$val){
                if(count($val['products'])){
                    $products = array();
                    foreach($val['products'] as $prow){
                        if($prow['container_id'] == $container_id){
                            $products[] = $prow;
                        }
                    }
                    $data[$key]['products'] = $products;
                }
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getBookingList($shipping_id){
        $data = array();
        $container = Shippings::where('id',$shipping_id)->first();
        $bookingProducts = BookingProducts::with('booking')->with('recepient_data')->where('shipping_id',$shipping_id)->get()->toArray();

        if(count($bookingProducts)){
            foreach($bookingProducts as $product){
                $arr = array();
                $arr['container_id'] = $container->container_name;
                $arr['booking_id'] = $product['booking']['reference_id'];
                $arr['item_id'] = $product['item_id'];
                $arr['title'] = $product['product_title_new'];
                $arr['amount'] = '£'.number_format($product['sub_amount'],2);
                $arr['recipient_name'] = $product['recepient_data']['name'];
                $arr['recipient_contact'] = $product['recepient_data']['phone'];
                $arr['recipient_location'] = $product['recepient_data']['address'];

                $data[] = $arr;
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function getShippingItemPDF($shipping_id){
        $data = array();
        $container = Shippings::where('id',$shipping_id)->first();
        $bookingProducts = BookingProducts::with('booking')->with('recepient_data')->where('shipping_id',$shipping_id)->get()->toArray();

        if(count($bookingProducts)){
            foreach($bookingProducts as $product){
                $arr = array();
                $arr['container_id'] = $container->container_name;
                $arr['booking_id'] = $product['booking']['reference_id'];
                $arr['item_id'] = $product['item_id'];
                $arr['title'] = $product['product_title_new'];
                $arr['amount'] = number_format($product['sub_amount'],2);
                $arr['recipient_name'] = $product['recepient_data']['name'];
                $arr['recipient_contact'] = $product['recepient_data']['phone'];
                $arr['recipient_location'] = $product['recepient_data']['address'];

                $data[] = $arr;
            }
        }

        $pdf = PDF::loadView('pdf/shipping_item_list', array('data'=>$data));
        return $pdf->download('ship_items.pdf');
    }

    public function bookingLoadedToConatiner($containerId,$bookingId){
        try{

            $bProducts = BookingProducts::where('booking_id',$bookingId)->get()->toArray();

            if(count($bProducts)){
                foreach($bProducts as $bpDet){
                    if($bpDet['is_loaded'] == 1 && $bpDet['is_wh_received'] == 1 && $bpDet['is_container_loaded'] == 0){
                        BookingProducts::where('id',$bpDet['id'])->update(array('container_id'=>$containerId,'is_container_loaded'=>1));
                    }
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Status changed successfully.'
                ));
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'eee'=> $e->getMessage(),
                'status' => 'ERROR'
            ));
        }
    }

    public function itemLoadedToConatiner($containerId,$bookingId,$bookingPId){
        try{

            $bpDet = BookingProducts::where('id',$bookingPId)->first();

            if($bpDet){
                if($bpDet['is_loaded'] == 1 && $bpDet['is_wh_received'] == 1 && $bpDet['is_container_loaded'] == 0){
                    BookingProducts::where('id',$bpDet['id'])->update(array('container_id'=>$containerId,'is_container_loaded'=>1));
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Status changed successfully.'
                ));
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'eee'=> $e->getMessage(),
                'status' => 'ERROR'
            ));
        }
    }

    public function bookingUnLoadedToConatiner($containerId,$bookingId){
        try{

            $bProducts = BookingProducts::where('booking_id',$bookingId)->get()->toArray();

            if(count($bProducts)){
                foreach($bProducts as $bpDet){
                    if($bpDet['is_loaded'] == 1 && $bpDet['is_wh_received'] == 1 && $bpDet['is_container_loaded'] == 1){
                        BookingProducts::where('id',$bpDet['id'])->update(array('container_id'=>0,'is_container_loaded'=>0));
                    }
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Status changed successfully.'
                ));
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'eee'=> $e->getMessage(),
                'status' => 'ERROR'
            ));
        }
    }

    public function itemUnLoadedToConatiner($containerId,$bookingId,$bookingPId){
        try{

            $bpDet = BookingProducts::where('id',$bookingPId)->first();

            if($bpDet){
                if($bpDet['is_loaded'] == 1 && $bpDet['is_wh_received'] == 1 && $bpDet['is_container_loaded'] == 1){
                    BookingProducts::where('id',$bpDet['id'])->update(array('container_id'=>0,'is_container_loaded'=>0));
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Status changed successfully.'
                ));
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'eee'=> $e->getMessage(),
                'status' => 'ERROR'
            ));
        }
    }

    public function markedContainer($id){
        Shippings::where('id',$id)->update(array('status'=>1));
        $data = Shippings::where('id',$id)->first();
        
        if($data){
            $bookingIds = BookingProducts::where('container_id',$data->container_no)->where('is_shipped',0)->pluck('booking_id')->toArray();
            Bookings::whereIn('id',$bookingIds)->update(array('shipping_id'=>$data->id));
            BookingProducts::where('container_id',$data->container_no)->where('is_shipped',0)->update(array('is_shipped'=>1,'shipping_id'=>$data->id));
            
            if(count($bookingIds)){
                foreach($bookingIds as $bookingId){
                    $bProducts = BookingProducts::where('booking_id',$bookingId)->where('is_shipped',0)->get()->toArray();

                    if(count($bProducts) == 0){
                        Bookings::where('id',$bookingId)->update(array('status'=>4));
                        TrackBooking::create(array('status'=>4,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));
                    }

                    $mailData = Bookings::with('pickup_details')->with('dropoff_details')->with('picked_driver')->with('products')->find($bookingId);

                    $sendTo = array($mailData['pickup_details']['email'], 'info@agyakooshipping.co.uk');
                    Mail::to($sendTo)->send(new OrderShipped($mailData));
                }

            }

        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shipping added successfully',
            'data' => $data
        ));
    }

    public function cancelShipping($id){
        Shippings::where('id',$id)->delete();

        BookingProducts::where('shipping_id',$id)->update(array('container_id'=>0, 'shipping_id'=>0, 'is_container_loaded'=>0));

        return response()->json(array(
            'status' => 'SUCCESS'
        ));
    }
}
