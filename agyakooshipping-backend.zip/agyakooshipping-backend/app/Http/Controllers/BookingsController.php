<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Bookings;
use App\Models\BookingProducts;
use App\Models\BookingDeliveryProducts;
use App\Models\BookingUserDetails;
use App\Models\AddressList;
use App\Models\UserAdresses;
use App\Models\User;
use App\Models\BookingPaymentHistory;
use App\Models\TrackBooking;
use App\Models\BookingDrivers;
use App\Models\Drivers;
use DB;
use Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Database\Eloquent\Builder;
use PDF;
use App\Mail\BookingCreated;
use Illuminate\Support\Facades\Mail;

class BookingsController extends Controller
{
    protected $UserId;
    public function __construct(Request $request)
    {
        $this->UserId = 0;
        $bToken = $request->bearerToken();
        if(isset($bToken)){
            $aToken = PersonalAccessToken::findToken($bToken);
            if(isset($aToken)){
                $this->UserId = $aToken->tokenable_id;
            }
        }
    }

    public function index(){
        $data = Bookings::orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function assignBookings(){
        $data = Bookings::with('pickup_details')->where('status',0)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function assignedBookings(){
        $data = Bookings::with('pickup_details')->with('dropoff_details')->with('driver')->with('products2')->where('status',1)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $delivery_products = array();
        $products = array();
        $dropOffData = array();
        $pickUpData = array();

        if(isset($postData['delivery_products'])){
            $delivery_products = $postData['delivery_products'];
            unset($postData['delivery_products']);
        }

        if(isset($postData['products'])){
            $products = $postData['products'];
            unset($postData['products']);
        }

        if(isset($postData['dropOffData'])){
            $dropOffData = $postData['dropOffData'];
            unset($postData['dropOffData']);
        }

        if(isset($postData['pickUpData'])){
            $pickUpData = $postData['pickUpData'];
            unset($postData['pickUpData']);
        }
        if(empty($postData['company_name'])){
            unset($postData['company_name']);
        }

        $postData['pickup_date'] = date('Y-m-d',strtotime($postData['pickup_date']));
        $postData['booking_date'] = date('Y-m-d');
        $postData['estimated_delivery_date'] = date('Y-m-d',strtotime("+15 days", strtotime($postData['pickup_date'])));
        $postData['added_by'] = $this->UserId;
        
       

        $data = Bookings::create($postData);

        if($data){
            TrackBooking::create(array('status'=>0,'datetime'=>$data->created_at,'booking_id'=>$data->id));
            $str = 'B'.str_pad($data->id, 6, "0", STR_PAD_LEFT);
            Bookings::where('id',$data->id)->update(array('reference_id'=>$str,'customer_type'=>'Registered'));

            $adr1 = AddressList::where('address',$pickUpData['address'])->where('type','pickup')->first();
            $adr2 = AddressList::where('address',$dropOffData['address'])->where('type','dropoff')->first();
            if(!$adr1){
                $addrNew = array();
                $addrNew['address'] = $pickUpData['address'];
                $addrNew['post_code'] = $pickUpData['post_code'];
                $addrNew['type'] = 'pickup';
                if(isset($pickUpData['latitude'])){
                    $addrNew['latitude'] = $pickUpData['latitude'];
                }
                if(isset($pickUpData['longitude'])){
                    $addrNew['longitude'] = $pickUpData['longitude'];
                }
                AddressList::create($addrNew);
            }
            if(!$adr2){
                $addrNew = array();
                $addrNew['address'] = $dropOffData['address'];
                $addrNew['type'] = 'dropoff';
                if(isset($dropOffData['latitude'])){
                    $addrNew['latitude'] = $dropOffData['latitude'];
                }
                if(isset($dropOffData['longitude'])){
                    $addrNew['longitude'] = $dropOffData['longitude'];
                }
                AddressList::create($addrNew);
            }

            if($postData['is_delivery'] == 1 && count($delivery_products)){
                foreach($delivery_products as $delivery_product){
                    $delivery_product['booking_id'] = $data->id;

                    $delProduct = BookingDeliveryProducts::create($delivery_product);

                    if($delProduct){
                        $str = 'BD'.str_pad($delProduct->id, 5, "0", STR_PAD_LEFT);
                        BookingDeliveryProducts::where('id',$delProduct->id)->update(array('item_id'=>$str));
                    }
                }
            }

            if(count($products)){
                foreach($products as $product){
                    $product['booking_id'] = $data->id;

                    $prod = BookingProducts::create($product);

                    if($prod){
                        $str = 'BI'.str_pad($prod->id, 5, "0", STR_PAD_LEFT);
                        BookingProducts::where('id',$prod->id)->update(array('item_id'=>$str));
                    }
                }
            }

            $alt_phones1 = array();
            $alt_phones2 = array();
            if(count($pickUpData['alt_contact_nos'])){
                foreach($pickUpData['alt_contact_nos'] as $altNo){
                    $alt_phones1[] = $altNo['value'];
                }
            }
            if(count($dropOffData['alt_contact_nos'])){
                foreach($dropOffData['alt_contact_nos'] as $altNo){
                    $alt_phones2[] = $altNo['value'];
                }
            }

            $pdatanew = array('type'=>'pickup','name'=>$pickUpData['name'],'email'=>$pickUpData['email'],'phone'=>$pickUpData['phone'],'address'=>$pickUpData['address'],'post_code'=>$pickUpData['post_code'],'booking_id'=>$data->id,'alt_phones'=>serialize($alt_phones1));
            if(isset($pickUpData['latitude'])){
                $pdatanew['latitude'] = $pickUpData['latitude'];
            }
            if(isset($pickUpData['longitude'])){
                $pdatanew['longitude'] = $pickUpData['longitude'];
            }

            $ddatanew = array('type'=>'dropoff','name'=>$dropOffData['name'],'phone'=>$dropOffData['phone'],'address'=>$dropOffData['address'],'booking_id'=>$data->id,'alt_phones'=>serialize($alt_phones2));
            if(!empty($dropOffData['email'])){
                $ddatanew['email'] = $dropOffData['email'];
            }
            if(isset($dropOffData['latitude'])){
                $ddatanew['latitude'] = $dropOffData['latitude'];
            }
            if(isset($dropOffData['longitude'])){
                $ddatanew['longitude'] = $dropOffData['longitude'];
            }

            BookingUserDetails::create($pdatanew);
            BookingUserDetails::create($ddatanew);

            if(isset($pickUpData['addressObj']) && isset($pickUpData['addressObj']['value']) && $pickUpData['addressObj']['value'] == -1){
                $pdatanew2 = array('type'=>'pickup','name'=>$pickUpData['name'],'email'=>$pickUpData['email'],'phone'=>$pickUpData['phone'],'alt_phones'=>serialize($pickUpData['alt_contact_nos']),'address'=>$pickUpData['address'],'post_code'=>$pickUpData['post_code'],'customer_id'=>$data->customer_id);
                if(isset($pickUpData['latitude'])){
                    $pdatanew2['latitude'] = $pickUpData['latitude'];
                }
                if(isset($pickUpData['longitude'])){
                    $pdatanew2['longitude'] = $pickUpData['longitude'];
                }
                UserAdresses::create($pdatanew2);
            }
            if(isset($dropOffData['addressObj']) && isset($dropOffData['addressObj']['value']) && $dropOffData['addressObj']['value'] == -1){
                $ddatanew2 = array('type'=>'dropoff','name'=>$dropOffData['name'],'phone'=>$dropOffData['phone'],'alt_phones'=>serialize($dropOffData['alt_contact_nos']),'address'=>$dropOffData['address'],'customer_id'=>$data->customer_id);

                if(!empty($dropOffData['email'])){
                    $ddatanew2['email'] = $dropOffData['email'];
                }

                if(isset($dropOffData['latitude'])){
                    $ddatanew2['latitude'] = $dropOffData['latitude'];
                }
                if(isset($dropOffData['longitude'])){
                    $ddatanew2['longitude'] = $dropOffData['longitude'];
                }
                UserAdresses::create($ddatanew2);
            }

            $mailData = Bookings::with('pickup_details')->with('dropoff_details')->with('products')->find($data->id);
            $sendTo = array($mailData['pickup_details']['email'], 'info@agyakooshipping.co.uk');
            Mail::to($sendTo)->send(new BookingCreated($mailData));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking added successfully.',
            'data' => $data
        ));
    }
 
    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $delivery_products = array();
        $products = array();
        $dropOffData = array();
        $pickUpData = array();

        if(isset($postData['delivery_products'])){
            $delivery_products = $postData['delivery_products'];
            unset($postData['delivery_products']);
        }

        if(isset($postData['products'])){
            $products = $postData['products'];
            unset($postData['products']);
        }

        if(isset($postData['dropOffData'])){
            $dropOffData = $postData['dropOffData'];
            unset($postData['dropOffData']);
        }

        if(isset($postData['pickUpData'])){
            $pickUpData = $postData['pickUpData'];
            unset($postData['pickUpData']);
        }
        if(empty($postData['company_name'])){
            unset($postData['company_name']);
        }

        $postData['pickup_date'] = date('Y-m-d',strtotime($postData['pickup_date']));
        $postData['estimated_delivery_date'] = date('Y-m-d',strtotime("+15 days", strtotime($postData['pickup_date'])));
        $postData['last_edited_by'] = $this->UserId;

        Bookings::where('id',$id)->update($postData);

        $data = Bookings::find($id);

        $alt_phones1 = array();
        $alt_phones2 = array();
        if(count($pickUpData['alt_contact_nos'])){
            foreach($pickUpData['alt_contact_nos'] as $altNo){
                $alt_phones1[] = $altNo['value'];
            }
        }
        if(count($dropOffData['alt_contact_nos'])){
            foreach($dropOffData['alt_contact_nos'] as $altNo){
                $alt_phones2[] = $altNo['value'];
            }
        }

        $pdatanew = array('name'=>$pickUpData['name'],'email'=>$pickUpData['email'],'phone'=>$pickUpData['phone'],'address'=>$pickUpData['address'],'post_code'=>$pickUpData['post_code'],'alt_phones'=>serialize($alt_phones1));
        if(isset($pickUpData['latitude'])){
            $pdatanew['latitude'] = $pickUpData['latitude'];
        }
        if(isset($pickUpData['longitude'])){
            $pdatanew['longitude'] = $pickUpData['longitude'];
        }

        $ddatanew = array('name'=>$dropOffData['name'],'phone'=>$dropOffData['phone'],'address'=>$dropOffData['address'],'alt_phones'=>serialize($alt_phones2));
        if(!empty($dropOffData['email'])){
            $ddatanew['email'] = $dropOffData['email'];
        }
        if(isset($dropOffData['latitude'])){
            $ddatanew['latitude'] = $dropOffData['latitude'];
        }
        if(isset($dropOffData['longitude'])){
            $ddatanew['longitude'] = $dropOffData['longitude'];
        }

        BookingUserDetails::where('booking_id',$id)->where('type','pickup')->update($pdatanew);
        BookingUserDetails::where('booking_id',$id)->where('type','dropoff')->update($ddatanew);

        if(isset($pickUpData['addressObj']) && isset($pickUpData['addressObj']['value']) && $pickUpData['addressObj']['value'] == -1){
            $pdatanew2 = array('type'=>'pickup','name'=>$pickUpData['name'],'email'=>$pickUpData['email'],'phone'=>$pickUpData['phone'],'alt_phones'=>serialize($pickUpData['alt_contact_nos']),'address'=>$pickUpData['address'],'post_code'=>$pickUpData['post_code'],'customer_id'=>$data->customer_id);
            if(isset($pickUpData['latitude'])){
                $pdatanew2['latitude'] = $pickUpData['latitude'];
            }
            if(isset($pickUpData['longitude'])){
                $pdatanew2['longitude'] = $pickUpData['longitude'];
            }
            UserAdresses::create($pdatanew2);
        }
        if(isset($dropOffData['addressObj']) && isset($dropOffData['addressObj']['value']) && $dropOffData['addressObj']['value'] == -1){
            $ddatanew2 = array('type'=>'dropoff','name'=>$dropOffData['name'],'phone'=>$dropOffData['phone'],'alt_phones'=>serialize($dropOffData['alt_contact_nos']),'address'=>$dropOffData['address'],'customer_id'=>$data->customer_id);

            if(!empty($dropOffData['email'])){
                $ddatanew2['email'] = $dropOffData['email'];
            }

            if(isset($dropOffData['latitude'])){
                $ddatanew2['latitude'] = $dropOffData['latitude'];
            }
            if(isset($dropOffData['longitude'])){
                $ddatanew2['longitude'] = $dropOffData['longitude'];
            }
            UserAdresses::create($ddatanew2);
        }

        if($postData['is_delivery'] == 1 && count($delivery_products)){
            $allIds = BookingDeliveryProducts::where('booking_id',$id)->pluck('id')->toArray();
            $updatedIds = array();
            foreach($delivery_products as $delivery_product){

                if($delivery_product['id'] > 0){
                    $updatedIds[] = $delivery_product['id'];

                    BookingDeliveryProducts::where('id',$delivery_product['id'])->update($delivery_product);
                }else{
                    $delivery_product['booking_id'] = $data->id;

                    $delProduct = BookingDeliveryProducts::create($delivery_product);
                    if($delProduct){
                        $str = 'BD'.str_pad($delProduct->id, 5, "0", STR_PAD_LEFT);
                        BookingDeliveryProducts::where('id',$delProduct->id)->update(array('item_id'=>$str));
                    }
                }
            }

            $deletedIds = array_diff($allIds,$updatedIds);
            BookingDeliveryProducts::whereIn('id',$deletedIds)->delete();
        }else{
            BookingDeliveryProducts::where('booking_id',$id)->delete();
        }

        if(count($products)){
            $allIds = BookingProducts::where('booking_id',$id)->pluck('id')->toArray();
            $updatedIds = array();
            foreach($products as $product){
                if($product['id'] > 0){
                    $updatedIds[] = $product['id'];

                    BookingProducts::where('id',$product['id'])->update($product);
                }else{
                    $product['booking_id'] = $data->id;

                    $prod = BookingProducts::create($product);

                    if($prod){
                        $str = 'BI'.str_pad($prod->id, 5, "0", STR_PAD_LEFT);
                        BookingProducts::where('id',$prod->id)->update(array('item_id'=>$str));
                    }
                }
            }
            $deletedIds = array_diff($allIds,$updatedIds);
            BookingProducts::whereIn('id',$deletedIds)->delete();
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking updated successfully',
            'data' => $data
        ));
    }
 
    public function show($id){
        $data = Bookings::with('picked_driver')->with('delivery_driver')->with('customer')->with('guestCustomer')->with('products')->with('delivery_products')->with('pickup_details')->with('dropoff_details')->with('payments')->with('images')->with('delivery_images')->select('*','id as detail_id')->find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Booking details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }
 
    public function show2($id){
        $data = Bookings::with('customer')->with('products2')->with('delivery_products2')->with('pickup_details')->with('dropoff_details')->find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Booking details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();
        $updateData = array();

        if(array_key_exists('payment_status',$postData)){
            if($postData['payment_status'] == 1){
                $bData = DB::table('bookings')->where('id',$id)->select('total','paid_amount')->first();
                $balance = floatval($bData->total)-floatval($bData->paid_amount);
                $updateData['payment_status'] = 1;
                $updateData['paid_amount'] = floatval($bData->total);
            }else{
                $updateData['payment_status'] = 0;
                $updateData['paid_amount'] = 0;
            }
        }else{
            $updateData = $postData;
        }

        Bookings::where('id', $id)->update($updateData);
        $data = Bookings::find($id);

        if(isset($postData['status']) && $postData['status'] == -1){
            TrackBooking::create(array('status'=>-1,'description'=>$postData['cancel_note'],'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$id));
        }

        if(array_key_exists('payment_status',$postData)){
            if($postData['payment_status'] == 1){
               BookingPaymentHistory::create(array('added_by'=>$this->UserId,'amount'=>@$balance,'note'=>@$postData['note'],'booking_id'=>$id));
            }else{
                BookingPaymentHistory::where('booking_id',$id)->delete();
            }
            
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Bookings::find($id);
        if($data){
            Bookings::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Booking deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }

    public function getBookingProducts($booking_id){
        $bookingData = Bookings::where('reference_id',$booking_id)->first();
        if($bookingData){
            if($bookingData->status == -1){
                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Booking item list got successfully.',
                    'data' => array()
                ));
            }

            $data = BookingProducts::with('driver')->with('recepient_data')->with('booking_status')->where('booking_id',$bookingData->id)->orderByDesc('id')->get()->toArray();

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Booking item list got successfully.',
                'data' => $data
            ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Booking id not found',
        ));
    }

    public function getBookingItemPDF($id){
        $customPaper = array(0,0,500.00,320.00);
        $data = BookingProducts::with('booking')->with('recepient_data')->where('booking_id',$id)->orderBy('id')->get()->toArray();

        $pdf = PDF::loadView('pdf/booking_items_qr', array('data'=>$data))->setPaper($customPaper, 'landscape');
        return $pdf->download('item_codes.pdf');
    }

    public function getPickedItem(){
        //$data = BookingProducts::with('booking')->with('pickup_data')->where('is_loaded',1)->where('is_wh_received',0)->orderByDesc('id')->get()->toArray();
        $data = Bookings::with('products')->with('pickup_details')->where('status',2)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function makeAsReceived(Request $request){
        $postData = $request->all();

        if(count($postData['bookingPIds'])){
            foreach($postData['bookingPIds'] as $bookingPId){
                $bpDet = BookingProducts::where('id',$bookingPId)->first();

                if($bpDet['is_loaded'] == 1 || $bpDet['is_wh_received'] == 0){
                    BookingProducts::where('id',$bookingPId)->update(array('is_wh_received'=>1));

                    $bProducts = BookingProducts::where('booking_id',$bpDet['booking_id'])->where('is_wh_received',0)->get()->toArray();

                    if(count($bProducts) == 0){
                        Bookings::where('id',$bpDet['booking_id'])->update(array('status'=>3));
                        BookingDrivers::where('booking_id',$bpDet['booking_id'])->update(array('is_received'=>1));
                        TrackBooking::create(array('status'=>3,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bpDet['booking_id']));
                    }

                    
                }

            }

            return response()->json(array(
                        'status' => 'SUCCESS',
                        'message' => 'Item(s) received successfully.'
                    ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.',
        ));
    }

    public function sendTestMail($booking_id){
        $mailData = Bookings::with('pickup_details')->with('dropoff_details')->with('products')->find($booking_id);;
        Mail::to('test@gmail.com')->send(new BookingCreated($mailData));


        return response()->json(array(
            'status' => 'ERROR',
            'mailData' => $mailData
        ));
    }

    public function addPayment(Request $request, $id){
        $postData = $request->all();
        $updateData = array(); 

        $bData = DB::table('bookings')->where('id',$id)->select('total','paid_amount')->first();
        $balance = floatval($bData->total)-floatval($bData->paid_amount);
        if($balance <= floatval($postData['amount'])){
            $updateData['payment_status'] = 1;
        }

        $updateData['paid_amount'] = floatval($bData->paid_amount) + floatval($postData['amount']);

        Bookings::where('id', $id)->update($updateData);
        $data = Bookings::find($id);

        BookingPaymentHistory::create(array('added_by'=>$this->UserId,'amount'=>$postData['amount'],'note'=>$postData['note'],'payment_method'=>$postData['payment_method'],'booking_id'=>$id));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Payment added successfully',
            'data' => $data
        ));
    }

    public function getDriverReport(){
        $data = Drivers::with(['assigned_bookings'])->where('status',1)->where('type','Pickup Driver')->select('id','driver_id','name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver report got successfully',
            'data' => $data
        ));
    }
}
