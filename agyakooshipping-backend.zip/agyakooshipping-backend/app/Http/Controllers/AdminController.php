<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use App\Models\Bookings;
use App\Models\BookingProducts;
use App\Models\BookingDeliveryProducts;
use App\Models\BookingUserDetails;
use App\Models\AddressList;
use App\Models\UserAdresses;
use App\Models\User;
use App\Models\Drivers;
use App\Models\BookingDrivers;
use App\Models\TrackBooking;
use DB;

class AdminController extends Controller
{
    public function getUserAddresses($user_id,$type){
        $primaryData = array();
        if($type == 'pickup'){
            $primaryData = Customer::where('id',$user_id)->select(DB::raw('0 as value'),'name as label','email','phone','alt_phones','address','post_code','latitude','longitude')->get()->toArray();
        }
        $data = UserAdresses::select('id as value','name as label','email','phone','alt_phones','address','post_code','latitude','longitude')->where('customer_id',$user_id)->where('type',$type)->orderBy('name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'User address list got successfully.',
            'data' => array_merge($primaryData,$data)
        ));
    }

    public function customerList(){
        $data = Customer::join('users','users.id','=','customers.user_id')->select('customers.*','customers.user_id as root_id','users.status')->orderByDesc('customers.id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Customer list got successfully.',
            'data' => $data
        ));
    }

    public function getPickupDriverDDList(){
        $data = Drivers::select('drivers.id as value','drivers.name as label')->where('type','Pickup Driver')->orderBy('drivers.name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver list got successfully.',
            'data' => $data
        ));
    }

    public function assignBookings(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                Bookings::where('id',$bookingId)->update(array('status'=>1));

                $pickUpData = Bookings::where('id',$bookingId)->pluck('pickup_date')->first();

                BookingDrivers::where('booking_id',$bookingId)->where('driver_id',$postData['driver_id'])->delete();

                BookingDrivers::create(array('booking_id'=>$bookingId,'driver_id'=>$postData['driver_id'],'pickup_date'=>$pickUpData ));

                TrackBooking::create(array('status'=>1,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));

            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver assigned successfully.',
        ));
    }

    public function reassignBookings(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                BookingDrivers::where('booking_id',$bookingId)->delete();

                $pickUpData = Bookings::where('id',$bookingId)->pluck('pickup_date')->first();

                
                BookingDrivers::create(array('booking_id'=>$bookingId,'driver_id'=>$postData['driver_id'],'pickup_date'=>$pickUpData));

                TrackBooking::where('booking_id',$bookingId)->where('status',1)->update(array('datetime'=>date('Y-m-d H:i:s')));
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver assigned successfully.',
        ));
    }

    public function unassignBookings(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                Bookings::where('id',$bookingId)->update(array('status'=>0));

                BookingDrivers::where('booking_id',$bookingId)->delete();

                TrackBooking::where('booking_id',$bookingId)->where('status',1)->delete();
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver unassigned successfully.',
        ));
    }

}
