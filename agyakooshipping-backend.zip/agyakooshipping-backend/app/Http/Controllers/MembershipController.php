<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Membership;
use DB;
use Validator;
use Laravel\Sanctum\PersonalAccessToken;

class MembershipController extends Controller
{
    public function index(){
        $data = Membership::where('is_deleted',0)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Membership list got successfully.',
            'data' => $data
        ));
    }
        public function getMembershipList(){
        $data = Membership::where('is_deleted',0)->where('status',1)->select('id as value','name as label','duration','price','discount')->orderBy('name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Membership list got successfully.',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['name'] = 'required';
       

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $membershipData['name'] = $postData['name'];
        $membershipData['duration'] = $postData['duration'];
        $membershipData['price'] = $postData['price'];
        $membershipData['discount'] = $postData['discount'];
        $membershipData['status'] = 1;
        $id = Membership::create($membershipData);
        if($id){
            $ids = str_pad($id->id, 5, "0", STR_PAD_LEFT);
            Membership::where('id',$id->id)->update(array('Membership_id'=>'MS'.$ids));
            $data = Membership::find($id->id);
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Membership added successfully',
            'data' => $data,  
            'data1' => $id,  
        ));
    }

    public function show($id){
        $data = Membership::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Membership details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $membershipData['name'] = $postData['name'];
        $membershipData['duration'] = $postData['duration'];
        $membershipData['price'] = $postData['price'];
        $membershipData['discount'] = $postData['discount'];

        Membership::where('id',$id)->update($membershipData);
        $data = Membership::find($id);
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Membership updated successfully',
            'data' => $data
        ));
    }

    public function update(Request $request, $id){
        $postData = $request->all();

        Membership::where('id', $id)->update($postData);
        $data = Membership::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Membership updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Membership::find($id);
        if($data){
            Membership::where('id', $id)->update(array('is_deleted'=>1));
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Membership deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }
}
