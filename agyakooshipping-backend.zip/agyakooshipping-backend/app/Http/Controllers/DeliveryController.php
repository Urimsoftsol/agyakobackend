<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Shippings;
use App\Models\Bookings;
use App\Models\TrackBooking;
use App\Models\BookingProducts;
use App\Models\Drivers;
use App\Models\BookingDeliveryDrivers;
use DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use App\Mail\OrderDeliverred;

class DeliveryController extends Controller
{
    public function getShippingDDList(){
        $data = Shippings::join('shipping_containers','shipping_containers.id','=','shippings.container_no')->whereIn('shippings.status',[1,2])->select('shippings.id as value', 'shipping_containers.container_no as label', DB::raw("CONCAT(shipping_containers.container_no,' (',shippings.reference_id,')') AS label"))->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shiiping list got successfully.',
            'data' => $data
        ));
    }

    public function getShippingDetails($id){
        $data = Shippings::where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shiiping details got successfully.',
            'data' => $data
        ));
    }

    public function getShippingReceived($id){
        Shippings::where('id',$id)->update(array('status'=>2,'arrival_date'=>date('Y-m-d')));
        $data = Shippings::where('id',$id)->first();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Shipping updated successfully',
            'data' => $data
        ));
    }

    public function getBookingListShip($ship_id){
        $subQuery1= DB::table('booking_products')->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');
        $subQuery2= DB::table('booking_products')->where('is_shipped',1)->where('is_ship_received',0)->where('shipping_id',$ship_id)->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');
        $subQuery3= DB::table('booking_products')->where('is_shipped',1)->where('is_ship_received',0)->where('shipping_id',$ship_id)->select('booking_products.booking_id',DB::raw("COUNT(booking_products.sub_amount) as total"))->groupBy('booking_products.booking_id');

        $data = Bookings::with('products')->with('pickup_details')->with('dropoff_details')->joinSub($subQuery1, 'subQuery1', function ($join) {
            $join->on('subQuery1.booking_id', '=', 'bookings.id');
        })->leftJoinSub($subQuery2, 'subQuery2', function ($join) {
            $join->on('subQuery2.booking_id', '=', 'bookings.id');
        })->leftJoinSub($subQuery3, 'subQuery3', function ($join) {
            $join->on('subQuery3.booking_id', '=', 'bookings.id');
        })->select('id','reference_id',DB::Raw('IFNULL( subQuery1.total , 0 ) as no_of_item'),DB::Raw('IFNULL( subQuery2.total , 0 ) as no_of_item2'),DB::Raw('IFNULL( subQuery3.total , 0 ) as no_of_item3'))->having('no_of_item3', '>', 0)->get()->toArray();

        if(count($data)){
            foreach($data as $key=>$val){
                if(count($val['products'])){
                    $products = array();
                    foreach($val['products'] as $prow){
                        if($prow['shipping_id'] == $ship_id){
                            $products[] = $prow;
                        }
                    }
                    $data[$key]['products'] = $products;
                }
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'List got successfully.',
            'data' => $data
        ));
    }

    public function itemReceived($shipping_id,$booking_id,$item_id){
        try{

            $bItem = BookingProducts::where('id',$item_id)->where('is_shipped',1)->where('is_ship_received',0)->first();

            if($bItem){
                BookingProducts::where('id',$item_id)->where('is_shipped',1)->where('is_ship_received',0)->update(array('is_ship_received'=>1));

                $allBookingItems = BookingProducts::where('booking_id',$booking_id)->where('is_shipped',1)->where('is_ship_received',0)->get()->toArray();

                if(count($allBookingItems) === 0){
                    Bookings::where('id',$booking_id)->update(array('status'=>5));
                    TrackBooking::create(array('status'=>5,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$booking_id));
                }

                $allShippingItems = BookingProducts::where('shipping_id',$shipping_id)->where('is_shipped',1)->where('is_ship_received',0)->get()->toArray();

                if(count($allShippingItems) === 0){
                    Shippings::where('id',$shipping_id)->update(array('status'=>3));
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Item Received successfully.'
                ));
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'eee'=> $e->getMessage(),
                'status' => 'ERROR'
            ));
        }
    }

    public function itemReceivedAll($shipping_id,$booking_id){
        try{

            $bookingItems = BookingProducts::where('shipping_id',$shipping_id)->where('booking_id',$booking_id)->where('is_shipped',1)->where('is_ship_received',0)->get()->toArray();

            if(count($bookingItems)){
                foreach($bookingItems as $item){
                    BookingProducts::where('id',$item['id'])->where('is_shipped',1)->where('is_ship_received',0)->update(array('is_ship_received'=>1));
                }
                

                $allBookingItems = BookingProducts::where('booking_id',$booking_id)->where('is_shipped',1)->where('is_ship_received',0)->get()->toArray();

                if(count($allBookingItems) === 0){
                    Bookings::where('id',$booking_id)->update(array('status'=>5));
                    TrackBooking::create(array('status'=>5,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$booking_id));
                }

                $allShippingItems = BookingProducts::where('shipping_id',$shipping_id)->where('is_shipped',1)->where('is_ship_received',0)->get()->toArray();

                if(count($allShippingItems) === 0){
                    Shippings::where('id',$shipping_id)->update(array('status'=>3));
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Item Received successfully.'
                ));
            }

            return response()->json(array(
                'status' => 'ERROR'
            ));
            
        }catch(\Exception $e){
            return response()->json(array(
                'eee'=> $e->getMessage(),
                'status' => 'ERROR'
            ));
        }
    }

    public function assignBookings(){
        $assignedBookings = BookingDeliveryDrivers::pluck('booking_id')->toArray();

        $data = Bookings::with('dropoff_details')->whereNotIn('id',$assignedBookings)->where('status',5)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function getPickupDriverDDList(){
        $data = Drivers::select('drivers.id as value','drivers.name as label')->where('type','GH Driver')->orderBy('drivers.name')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver list got successfully.',
            'data' => $data
        ));
    }

    public function assignDriverBookings(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                BookingDeliveryDrivers::where('booking_id',$bookingId)->where('driver_id',$postData['driver_id'])->delete();

                BookingDeliveryDrivers::create(array('booking_id'=>$bookingId,'driver_id'=>$postData['driver_id'],'delivered_date'=>date('Y-m-d')));

                Bookings::where('id',$bookingId)->update(array('status'=>6));

                BookingProducts::where('booking_id',$bookingId)->update(array('is_out_for_delivery'=>1));
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver assigned successfully.',
        ));
    }

    public function reassignBookings(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                BookingDeliveryDrivers::where('booking_id',$bookingId)->delete();

                BookingDeliveryDrivers::create(array('booking_id'=>$bookingId,'driver_id'=>$postData['driver_id'],'delivered_date'=>date('Y-m-d')));
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver assigned successfully.',
        ));
    }

    public function unassignBookings(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                BookingDeliveryDrivers::where('booking_id',$bookingId)->delete();
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver unassigned successfully.',
        ));
    }

    public function assignedBookings(){
        $assignedBookings = BookingDeliveryDrivers::pluck('booking_id')->toArray();
        $data = Bookings::with('products')->with('pickup_details')->with('dropoff_details')->with('delivery_driver')->whereIn('id',$assignedBookings)->where('status',6)->orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function makeAsDelivered(Request $request){
        $postData = $request->all();

        if(count($postData['bookingIds'])){
            foreach($postData['bookingIds'] as $bookingId){
                BookingDeliveryDrivers::where('booking_id',$bookingId)->where('is_failed',0)->update(array('is_deliverred'=>1,'delivered_date'=>date('Y-m-d')));

                BookingProducts::where('booking_id',$bookingId)->update(array('is_deliverred'=>1, 'delivered_date'=>date('Y-m-d H:i:s')));

                Bookings::where('id',$bookingId)->update(array('status'=>7, 'estimated_delivery_date'=>date('Y-m-d H:i:s')));

                TrackBooking::create(array('status'=>7,'datetime'=>date('Y-m-d H:i:s'),'booking_id'=>$bookingId));

                $mailData = Bookings::with('pickup_details')->with('dropoff_details')->with('picked_driver')->with('delivery_driver')->with('products')->find($bookingId);

                $sendTo = array($mailData['pickup_details']['email'], 'info@agyakooshipping.co.uk');
                Mail::to($sendTo)->send(new OrderDeliverred($mailData));

            }

            return response()->json(array(
                        'status' => 'SUCCESS',
                        'message' => 'Item(s) deliverred successfully.'
                    ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Error occured.',
        ));
    }

}
