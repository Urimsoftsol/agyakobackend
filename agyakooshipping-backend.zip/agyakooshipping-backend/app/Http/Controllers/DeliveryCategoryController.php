<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\delivery_category;
use DB;
use Validator;

class DeliveryCategoryController extends Controller
{
    public function index(){
        $data = delivery_category::orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery category list got successfully',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $postData['status'] = 1;

        $data = delivery_category::create($postData);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery category added successfully',
            'data' => $data
        ));
    }
 
    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';


        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }
        delivery_category::where('id',$id)->update($postData);
        $data = delivery_category::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery category updated successfully',
            'data' => $data
        ));
    }
 
    public function show($id){
        $data = delivery_category::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Delivery category details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();

        delivery_category::where('id', $id)->update($postData);
        $data = delivery_category::find($id);


        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Delivery category updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = delivery_category::find($id);
        if($data){
            delivery_category::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Delivery category deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    } 
}
