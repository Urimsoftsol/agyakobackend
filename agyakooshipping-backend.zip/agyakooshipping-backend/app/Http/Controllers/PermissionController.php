<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Permission;
use App\Models\User_permission;
use DB;
use Validator;

class PermissionController extends Controller
{
    public function userPermissionParentList(){
        $data1 = Permission::where('parent',0)->orderByDesc('id')->get()->toArray();
        $data = array();
        if(count($data1)){
            foreach($data1 as $row){
                $data2['label'] = $row['title'];
                $data2['value'] = $row['id'];
                $data[] = $data2;
            }
        }
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Uesr permission list got successfully',
            'data' => $data
        ));
    }

    public function userPermissionList(){

        $data = array();
        $data2 = array();
        $users = Permission::where('parent',0)->get();

         
        if($users->isNotEmpty()){
            foreach ($users as $row) {
                $arr['id'] = $row->id;
                $arr['title'] = $row->title;
                $arr['children'] = array();
                $children = Permission::select('id','parent','title')->where('parent',$row->id)->get();
                if(count($children)){
                    foreach($children as $child){
                        $arr2 = $child;
                        $arr2['permissions'] = User_permission::where('permission_id',$child->id)->pluck('user_type')->toArray();

                        $arr['children'][] = $arr2;
                    }
                }

                $data[] = $arr;
            }
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Uesr permission list got successfully',
            'data' => $data
        ));
    }

    public function usersPermissionAdd(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';
        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $postData['parent']=$postData['parent']['value'];
        $postData['slug']  = $this->getSlugValue($postData['title'],$postData['parent'],1);

        $data = Permission::create($postData);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Permission added successfully',
            'data' => $data
        ));
    }

    public function getSlugValue($title, $parent=0, $depth=1){
        if($depth == 1){
            $title = strtolower($title);
            $title = str_replace(' ', '-', $title);
            $title = preg_replace('/[^A-Za-z0-9\-]/', '', $title);

            if($parent > 0){
                $parentslug = Permission::where('id',$parent)->pluck('slug')->first();
                $title = $parentslug.':'.$title;
            }
            $titleTemp = $title;
        }else{
            $titleTemp = $title.'-'.$depth;
        }

        $slugVal = Permission::where('slug',$titleTemp)->first();

        if($slugVal){
            return $this->getSlugValue($title,$parent,$depth+1);
        }

        if($depth == 1){
            return $title;
        }else{
            return $title.'-'.$depth;
        }
    }

    public function addRolePermission(Request $request){
        $data = User_permission::create(array('permission_id'=>$request->permission_id,'user_type'=>$request->user_type));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Role permission added successfully',
            'data' => $data
        ));
    }

    public function deleteRolePermission(Request $request){
        User_permission::where('permission_id',$request->permission_id)->where('user_type',$request->user_type)->delete();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Role permission deleted successfully'
        ));
    }

}
