<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Mail\SendCodeResetPassword;
use Illuminate\Support\Facades\Mail;
use Validator;

class ForgotPasswordController extends Controller
{
    public function sendmail(Request $request){
        $data = $request->all();
        $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        $validator = Validator::make($data, array('email'=> 'required|email|exists:users'));

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        $data['token'] = substr(str_shuffle(str_repeat($chars, ceil(6/strlen($chars)) )),1,6);

        $codeData = DB::table('password_reset_tokens')->insert($data);

        Mail::to($request->email)->send(new SendCodeResetPassword($data['token']));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Code has been sent to you email. Check your mail and enter code.'
        ));
    }

    public function checkcode(Request $request){
        $data = $request->all();

        $validator = Validator::make($data, array('token'=> 'required|string|exists:password_reset_tokens'));

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $passwordReset = DB::table('password_reset_tokens')->where('token', $request->token)->first();

        /*if ($passwordReset->created_at > now()->addHour()) {
            DB::table('password_reset_tokens')->where('token', $request->token)->delete();

            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Code is expired'
            ));
        }*/

        return response([
            'status' => 'SUCCESS',
            'token' => $passwordReset->token,
            'message' => "Code validate successfully"
        ]);
    }

    public function reset(Request $request){
        $data = $request->all();

        $validator = Validator::make($data, array('token'=> 'required|string|exists:password_reset_tokens', 'password'=> 'required|string|min:6|confirmed'));

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $passwordReset = DB::table('password_reset_tokens')->where('token', $request->token)->first();

        /*if ($passwordReset->created_at > now()->addHour()) {
            DB::table('password_reset_tokens')->where('token', $request->token)->delete();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Code is expired'
            ));
        }*/

        User::where('email', $passwordReset->email)->update(array('password'=>Hash::make($request->password)));

        DB::table('password_reset_tokens')->where('token', $request->token)->delete();

        return response([
            'status' => 'SUCCESS',
            'message' => "Password has been successfully reset"
        ]);
    }
}
