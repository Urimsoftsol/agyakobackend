<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Support\Facades\Hash;
use Auth;
use App\Models\User;
use App\Models\Customer;
use Validator;

class AuthController extends Controller
{
    public function login(Request $request){
        $postData = $request->all();


        $rules = array();
        $rules['email'] = 'required';
        $rules['password'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        if (Auth::guard()->attempt(array('email'=>$postData['email'],'password'=>$postData['password']))) {
            $user = Auth::user();
            if($user->status == 1){
                $token = $user->createToken($user->name,array('*'),now()->addHours(24))->plainTextToken;
                $user ->api_token = $token;
                if($user->user_type == 'Customer'){
                    $user->customer = Customer::where('user_id',$user->id)->first();
                }

                return response()->json(array(
                    'status' => 'SUCCESS',
                    'message' => 'Logged in successfully',
                    'data' => $user
                ));
            }else{
                return response()->json(array(
                    'status' => 'ERROR',
                    'message' => 'This user is inactive now. Please contact admin.'
                ));
            }
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Sorry, that username or password is incorrect. Please try again.'
            ));
        }
    }

    public function logout(Request $request){
        $bearerToken = $request->bearerToken();
        $token = PersonalAccessToken::findToken($bearerToken);

        $token->delete();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Logged out successfully'
        ));
    }

    public function signup(Request $request){
        $postData = $request->all();


        $rules = array();
        $rules['email'] = 'required|email|unique:users';
        $rules['password'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $nameArr = array();
        $nameArr[] = $postData['first_name'];
        $nameArr[] = $postData['last_name'];

        $userData['name'] = implode(' ', $nameArr);
        $userData['email'] = $customerData['email'] = $postData['email'];
        $userData['phone'] = $postData['phone'];
        $userData['password'] = Hash::make($postData['password']);
        $userData['status'] = 1;
        $userData['user_type'] = $postData['user_type'];

        $data = User::create($userData);

        if($data){
            $customerData['user_id'] = $data->id;
            $customerData['first_name'] = $postData['first_name'];
            $customerData['last_name'] = $postData['last_name'];
            $customerData['phone'] = $postData['phone'];

            $customer = Customer::create($customerData);

            $ids = str_pad($customer->id, 5, "0", STR_PAD_LEFT);
            Customer::where('id',$customer->id)->update(array('customer_id'=>'C'.$ids));
        }

        if (Auth::guard()->attempt(array('email'=>$postData['email'],'password'=>$postData['password']))) {
            $user = Auth::user();
            
            $token = $user->createToken($user->name,array('*'),now()->addHours(24))->plainTextToken;
            $user ->api_token = $token;
            $user ->user_type = intval($user ->user_type);
            $user ->status = intval($user ->status);

            if($user->user_type == 'Customer'){
                $user->customer_details = Customer::where('user_id',$user->id)->select('first_name','last_name','email','phone','address','state','city','zipcode','age')->first();
            }

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Signed up successfully',
                'data' => $user
            ));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Signed up successfully',
            'data' => $data
        ));
    }
}
