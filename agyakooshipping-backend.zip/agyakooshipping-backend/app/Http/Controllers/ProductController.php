<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use DB;
use Validator;
class ProductController extends Controller
{
    public function index(){
        $data = Product::orderBy('title')->orderBy('parent_id')->get()->toArray();
        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Product list got successfully',
            'data' => $data
        ));
    }
    public function categoryList(){     
        $data = Product::where('parent_id',0)->where('status',1)->select('id as value','title as label')->orderBy('title')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Category list got successfully',
            'data' => $data
        ));    
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $postData['status'] = 1;

        $data = Product::create($postData);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Product added successfully',
            'data' => $data
        ));
    }
 
    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $rules = array();
        $rules['title'] = 'required';


        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }
        Product::where('id',$id)->update($postData);
        $data = Product::find($id);

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Product updated successfully',
            'data' => $data
        ));
    }
 
    public function show($id){
        $data = Product::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Product details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function update(Request $request, $id){
        $postData = $request->all();

        Product::where('id', $id)->update($postData);
        $data = Product::find($id);
 

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Product updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Product::find($id);
        if($data){
            Product::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Product deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    } 
}
