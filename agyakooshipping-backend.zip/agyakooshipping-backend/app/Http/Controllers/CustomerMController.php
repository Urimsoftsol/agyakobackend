<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Sanctum\PersonalAccessToken;
use App\Models\Bookings;
use App\Models\Customer;
use App\Models\User;
use DB;
use Illuminate\Support\Facades\Hash;

class CustomerMController extends Controller
{
    protected $customer;

    public function __construct(Request $request){
        $bearerToken = $request->bearerToken();
        $token = PersonalAccessToken::findToken($bearerToken);
        if($token){
            $user = $token->tokenable;
            $this->customer = DB::table('customers')->where('user_id',$user['id'])->first();
        }
    }

    public function getBookingList(){
        $data = array();

        if(isset($this->customer->id)){
            $data = Bookings::with('pickup_details')->where('customer_id',$this->customer->id)->where('customer_type','Registered')->orderByDesc('id')->get()->toArray();
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Booking list got successfully.',
            'data' => $data
        ));
    }

    public function updateProfile(Request $request){
        $postData = $request->all();
        $data = array();

        if(isset($this->customer->id)){
            $driverData['name'] = $postData['name'];
            $driverData['email'] = $postData['email'];
            $driverData['phone'] = $postData['phone'];
            $driverData['address'] = $postData['address'];
            $driverData['post_code'] = $postData['post_code'];
            $driverData['dob'] = $postData['dob'];
            $driverData['registered_company'] = $postData['registered_company'];
            if($postData['registered_company'] == 'Yes'){
                $driverData['company_name'] = $postData['company_name'];
                $driverData['company_shipping'] = $postData['company_shipping'];
            }

            Customer::where('id',$this->customer->id)->update($driverData);
            $data = Customer::find($this->customer->id);

            User::where('id',$data->user_id)->update(array('name'=>$postData['name'],'email'=>$postData['email'],'phone'=>$postData['phone']));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Profile updated successfully.',
            'data' => $data
        ));
    }

    public function changePassword(Request $request){
        $postData = $request->all();
        $data = array();

        if(isset($this->customer->id)){
            $data = Customer::find($this->customer->id);
            User::where('id',$data->user_id)->update(array('password'=>Hash::make($postData['password'])));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Password chnaged successfully.'
        ));
    }

    public function getBookingDetails($id){
        $data = Bookings::with('products')->with('pickup_details')->with('tracking_details')->where('reference_id',$id)->where('customer_id',$this->customer->id)->where('customer_type','Registered')->first();

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Booking details got successfully.',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'EROOR',
                'message' => 'Booking Id Not Found.'
            ));
        }

    }
}
