<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Drivers;
use DB;
use Validator;
use Laravel\Sanctum\PersonalAccessToken;

class DriversController extends Controller
{
    public function index(){
        $data = Drivers::orderByDesc('id')->get()->toArray();

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver list got successfully.',
            'data' => $data
        ));
    }

    public function store(Request $request){
        $postData = $request->all();

        $rules = array();
        $rules['name'] = 'required';
        $rules['email'] = 'required|email|unique:users';

        $validator=Validator::make($postData, $rules);

        if ($validator->fails()) {
            $messages = $validator->messages();
            $errors = $messages->all();
            return response()->json(array(
                'status' => 'ERROR',
                'error'=> 'Validation',
                'messages' => $messages,
                'message' => (is_array($errors)?$errors[0]:$errors)
            ));
        }

        $userData['name'] = $postData['name'];
        $userData['email'] = $postData['email'];
        $userData['phone'] = (isset($postData['mobile'])? $postData['mobile']:"");
        $userData['password'] = Hash::make($postData['password']);
        $userData['user_type'] = ($postData['location'] == 'UK Warehouse') ? 'Pickup Driver' : 'GH Driver';
        $userData['status'] = 1;

        $data = User::create($userData);

        if($data){
            $driverData['user_id'] = $data->id;
            $driverData['name'] = $postData['name'];
            $driverData['email'] = $postData['email'];
            $driverData['mobile'] =(isset($postData['mobile'])? $postData['mobile']:"");
            $driverData['address'] = @$postData['address'];
            $driverData['house_no'] = @$postData['house_no'];
            $driverData['dob'] = (isset($postData['dob'])? $postData['dob']:null);
            $driverData['driver_type'] = @$postData['driver_type'];
            $driverData['wage_type'] = @$postData['wage_type'];
            $driverData['location'] = @$postData['location'];
            $driverData['status'] = 1;
            $driverData['type'] = $userData['user_type'];

            $driver = Drivers::create($driverData);

            $ids = str_pad($driver->id, 5, "0", STR_PAD_LEFT);
            if($data->user_type == 'Pickup Driver'){
                Drivers::where('id',$driver->id)->update(array('driver_id'=>'DU'.$ids));
            }else{
                Drivers::where('id',$driver->id)->update(array('driver_id'=>'DG'.$ids));
            }

            $data = Drivers::find($driver->id);
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver added successfully',
            'data' => $data
        ));
    }

    public function show($id){
        $data = Drivers::find($id);

        if($data){
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Driver details got successfully',
                'data' => $data
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }

    }

    public function updateAll(Request $request, $id){
        $postData = $request->all();

        $driverData['name'] = $postData['name'];
        $driverData['email'] = $postData['email'];
        $driverData['mobile'] = $postData['mobile'];
        $driverData['address'] = $postData['address'];
        $driverData['house_no'] = $postData['house_no'];
        $driverData['dob'] = $postData['dob'];
        $driverData['driver_type'] = $postData['driver_type'];
        $driverData['wage_type'] = $postData['wage_type'];
        $driverData['location'] = $postData['location'];
        $driverData['type'] = (($postData['location'] == 'UK Warehouse') ? 'Pickup Driver' : 'GH Driver');

        $driver = Drivers::where('id',$id)->update($driverData);
        $data = Drivers::find($id);

        User::where('id',$data->user_id)->update(array('name'=>$postData['name'],'email'=>$postData['email'],'phone'=>$postData['mobile'],'user_type' => (($postData['location'] == 'UK Warehouse') ? 'Pickup Driver' : 'GH Driver')));

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver updated successfully',
            'data' => $data
        ));
    }

    public function update(Request $request, $id){
        $postData = $request->all();

        Drivers::where('id', $id)->update($postData);
        $data = Drivers::find($id);
        if(isset($postData['status'])){
            User::where('id',$data->user_id)->update(array('status'=>$postData['status']));
        }

        return response()->json(array(
            'status' => 'SUCCESS',
            'message' => 'Driver updated successfully',
            'data' => $data
        ));
    }

    public function delete($id){
        $data = Drivers::find($id);
        if($data){
            User::where('id',$data->user_id)->delete();
            Drivers::where('id', $id)->delete();
            
            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Driver deleted successfully.',
                'data' => $data->toArray()
            ));
        }else{
            return response()->json(array(
                'status' => 'ERROR',
                'message' => 'Id not found',
            ));
        }
    }

    public function changePassword(Request $request, $id){
        $userId = Drivers::where('id', $id)->pluck('user_id')->first();

        if($userId){
            User::where('id', $userId)->update(array('password'=>Hash::make($request->password)));

            return response()->json(array(
                'status' => 'SUCCESS',
                'message' => 'Password chnaged successfully',
            ));
        }

        return response()->json(array(
            'status' => 'ERROR',
            'message' => 'Id not found',
        ));
    }
}
