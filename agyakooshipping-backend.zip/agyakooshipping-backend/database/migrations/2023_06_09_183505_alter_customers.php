<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            $table->text('alt_phones')->nullable()->after('phone');
            $table->string('longitude')->default('')->after('address');
            $table->string('latitude')->default('')->after('address');
            $table->string('post_code')->default('')->after('address');
            $table->dropColumn('state');
            $table->dropColumn('city');
            $table->dropColumn('zipcode');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            //
        });
    }
};
