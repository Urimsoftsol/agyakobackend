<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('booking_user_details', function (Blueprint $table) {
            $table->string('longitude')->default('')->after('alt_phones');
            $table->string('latitude')->default('')->after('alt_phones');
            $table->string('post_code')->default('')->after('alt_phones');
            $table->text('address')->nullable()->after('alt_phones');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('booking_user_details', function (Blueprint $table) {
            //
        });
    }
};
