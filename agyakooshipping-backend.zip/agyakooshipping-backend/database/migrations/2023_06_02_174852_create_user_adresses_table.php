<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_adresses', function (Blueprint $table) {
            $table->id();
            $table->string('type')->default('');
            $table->string('name')->default('');
            $table->string('email')->default('');
            $table->string('phone')->default('');
            $table->text('alt_phones')->nullable();
            $table->text('address')->nullable();
            $table->string('post_code')->default('');
            $table->string('latitude')->default('');
            $table->string('longitude')->default('');
            $table->timestamps();
        });
        Schema::table('user_adresses', function (Blueprint $table) {
            $table->foreignId('customer_id')->constrained('users')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_adresses');
    }
};
