<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $table->string('shipping_id')->default('')->after('id');
            $table->string('reference_id')->default('')->after('id');
            $table->integer('no_of_items')->default(0)->after('user_id');
            $table->integer('is_delivery')->default(0)->after('user_id');
            $table->string('insurance')->default('')->after('user_id');
            $table->string('company_shipping')->default('')->after('user_id');
            $table->string('company_name')->default('')->after('user_id');
            $table->string('registered_company')->default('')->after('user_id');
            $table->time('pickup_time')->nullable()->after('amount');
            $table->date('pickup_date')->nullable()->after('amount');
            $table->float('total',10,2)->default(0)->after('amount');
            $table->float('vat',10,2)->default(0)->after('amount');
            $table->float('shipping',10,2)->default(0)->after('amount');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            //
        });
    }
};
