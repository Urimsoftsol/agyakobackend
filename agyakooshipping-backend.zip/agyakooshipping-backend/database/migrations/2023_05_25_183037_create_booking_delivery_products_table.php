<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('booking_delivery_products', function (Blueprint $table) {
            $table->id();
            $table->integer('product_id')->default(0);
            $table->float('price',10,2)->default(0);
            $table->integer('quantity')->default(0);
            $table->float('sub_amount',10,2)->default(0);
            $table->timestamps();
        });
        Schema::table('booking_delivery_products', function (Blueprint $table) {
            $table->foreignId('booking_id')->constrained('bookings')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('booking_delivery_products');
    }
};
