<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('drivers', function (Blueprint $table) {
            $table->id();
            $table->string('driver_id')->default('');
            $table->integer('user_id')->default(0);
            $table->string('name')->default('');
            $table->string('email')->default('');
            $table->string('land_line')->default('');
            $table->string('mobile')->default('');
            $table->string('address')->default('');
            $table->string('house_no')->default('');
            $table->date('dob')->nullable();
            $table->string('driver_type')->default('');
            $table->string('wage_type')->default('');
            $table->string('location')->default('');
            $table->string('type')->default('');
            $table->integer('status')->default(1);
            $table->integer('is_deleted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('drivers');
    }
};
