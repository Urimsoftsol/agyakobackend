<div style='max-width: 600px; width: 600px; margin: 0 auto; background: #fff; border-radius: 5px; padding-bottom: 28px; font-family: Roboto, sans-serif;'>
	<table style="width: 500px; border-bottom: 1px solid #000;">
		<tr>
				<td colspan="2">
					<p style='font-weight: bold; color: #008000; text-align: center; font-size: 28px; margin: 0; padding-bottom: 15px;'>Order Receipt</p>
					<p style='font-weight: bold; color: #000066; text-align: center; font-size: 16px; margin: 0; padding-bottom: 30px;'>Thank you for your order!</p>
				</td>
			</tr>
	<tr >
		<td>&nbsp;</td>
		<td style="padding:10px 3px; text-align: right;">
			<div style="font-size: 14px; font-weight: 800;">Agyakoo Shipping Ltd.</div>
			<div style="font-size: 13px; font-weight: 600;">31 Waleys Close, Luton, Lu3 3rz</div>
		</td>
	</tr>
</table>
<table style="width: 500px; border-bottom: 1px solid #000;">
	<tr >
		<td>&nbsp;</td>
		<td style="padding:10px 3px; text-align: right;">
			<div style="font-size: 13px; font-weight: 600;">Tel : +44 7853 607006</div>
		</td>
	</tr>
</table>
<table style="width: 500px;" cellspacing="0">
	<tr>
		<td style="padding: 10px 3px 5px; font-size: 13px; font-weight: 600; border-bottom: 1px solid #000;">Customer Details</td>
		<td style="border-bottom: 1px solid #000;">&nbsp;</td>
	</tr>
	<tr>
		<td style="padding: 10px 3px;">
			<div style="font-size: 12px;"><span style="font-weight: 700;">ID:</span> {{$data['customer']['customer_id']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Name:</span> {{$data['customer']['name']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Phone:</span> {{$data['customer']['phone']}}</div>
		</td>
		<td style="padding:10px 3px; text-align: right;">
			<div style="font-size: 12px;"><span style="font-weight: 700;">Booking ID:</span> {{$data['reference_id']}}</div>
		</td>
	</tr>
</table>
<table style="width: 500px;"  cellspacing="0">
	<tr>
		<td style="padding: 10px 3px 5px; font-size: 13px; font-weight: 600; border-bottom: 1px solid #000;">Pick Up Address</td>
		<td style="padding: 10px 3px 5px; font-size: 13px; font-weight: 600; border-bottom: 1px solid #000;">Recepient Addres</td>
	</tr>
	<tr style="border-bottom: 1px solid #000;">
		<td style="padding: 10px 3px;">
			<div style="font-size: 12px;"><span style="font-weight: 700;">Name:</span> {{$data['pickup_details']['name']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Address:</span> {{$data['pickup_details']['address']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Phone:</span> {{$data['pickup_details']['phone']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Postcode:</span> {{$data['pickup_details']['post_code']}}</div>
		</td>
		<td style="font-size: 12px;">
			<div style="font-size: 12px;"><span style="font-weight: 700;">Name:</span> {{$data['dropoff_details']['name']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Address:</span> {{$data['dropoff_details']['address']}}</div>
			<div style="font-size: 12px;"><span style="font-weight: 700;">Phone:</span> {{$data['dropoff_details']['phone']}}</div>
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
</table>
<table style="width: 500px;" cellspacing="0">
	<tr>
		<td style="font-size: 13px; font-weight: 600; padding: 10px 3px 5px; border-bottom: 1px solid #000;">Pickup ID</td>
		<td style="font-size: 13px; font-weight: 600; padding: 10px 3px 5px; border-bottom: 1px solid #000;">Pickup Item</td>
		<td style="font-size: 13px; font-weight: 600; padding: 10px 3px 5px; text-align: center; border-bottom: 1px solid #000;">Price</td>
	</tr>
	@if(count($data['products']))
		@foreach ($data['products'] as $item)
			<tr>
				<td style="padding:3px;">{{$item['item_id']}}</td>
				<td style="padding:3px;">{{$item['product_title_new']}}</td>
				<td style="padding: 3px; text-align: right;">£{{number_format($item['sub_amount'],2)}}</td>
			</tr>
		@endforeach
	@endif
	<tr>
		<td style="padding:3px; border-top: 1px solid #000;">&nbsp;</td>
		<td style="font-size: 13px; font-weight: 600; padding: 3px; text-align: right; border-top: 1px solid #000;">Sub Total</td>
		<td style="padding: 3px; text-align: right; border-top: 1px solid #000;">£{{number_format($data['amount'],2)}}</td>
	</tr>
	<tr>
		<td style="padding:3px;">&nbsp;</td>
		<td style="font-size: 13px; font-weight: 600; padding: 3px; text-align: right;">Discount</td>
		<td style="padding: 3px; text-align: right;">£00.00</td>
	</tr>
	<tr>
		<td style="padding:3px;">&nbsp;</td>
		<td style="font-size: 13px; font-weight: 600; padding: 3px; text-align: right;">Tax</td>
		<td style="padding: 3px; text-align: right;">£00.00</td>
	</tr>
	<tr>
		<td style="padding:3px; border-bottom: 1px solid #000;">&nbsp;</td>
		<td style="font-size: 14px; font-weight: 700; padding: 3px; text-align:right; border-bottom: 1px solid #000;">Total</td>
		<td style="padding: 3px; text-align: right; border-bottom: 1px solid #000;">£{{number_format($data['total'],2)}}</td>
	</tr>
</table>
</div>