<div>
	<div style="text-align: center; font-size: 20px; font-weight: 700;">AgyaKoo Shipping Conatct Us</div>


	<div><strong>Name:</strong> {{$params['firstname']}} {{$params['lastname']}}</div>
	<div><strong>Phone:</strong> {{$params['phone']}}</div>
	<div><strong>Email:</strong> {{$params['email']}}</div>
	<div><strong>Message:</strong> {{$params['message']}}</div>
</div>