<div>
	<div style="text-align: center; font-size: 20px; font-weight: 700;">AgyaKoo Shipping Invoice</div>

	<div style="margin-top: 20px; font-size: 24px; font-weight: 700; border-bottom: 1px #000 solid;">Booking Details</div>
	<div style="margin-top: 5px;">Dear {{@$params['customer_name']}},</div>
	<div>Thank you for Booking with AgyaKoo Shipping. Your booking has been received and is being processed. Kindly see details of your booking below.</div>
	<div>&nbsp;</div>
	<div style="margin-top: 7px; margin-bottom: 7px; font-size: 15px; font-weight: 600; text-decoration: underline;">Pickup Address</div>
	<div>{{$params['pickup_details']['name']}}</div>
	<div>{{$params['pickup_details']['address']}}</div>
	<div>{{$params['pickup_details']['post_code']}}</div>
	<div>{{$params['pickup_details']['phone']}}</div>
	<div>&nbsp;</div>
	<div style="margin-top: 7px; margin-bottom: 7px; font-size: 15px; font-weight: 600; text-decoration: underline;">Delivery Address</div>
	<div>{{$params['dropoff_details']['name']}}</div>
	<div>{{$params['dropoff_details']['address']}}</div>
	<div>{{$params['dropoff_details']['phone']}}</div>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
	<div><strong>Booking ID:</strong> {{$params['reference_id']}}</div>
	<div><strong>Collection Date:</strong>	{{date('d/m/Y',strtotime($params['pickup_date']))}}</div>
	<div><strong>Booking Date:</strong>	{{date('d/m/Y',strtotime($params['booking_date']))}}</div>
	<div><strong>Booking Notes:</strong></div>
	<div>&nbsp;</div>
	<div style="margin-top: 7px; margin-bottom: 7px; font-size: 15px; font-weight: 600; text-decoration: underline;">Item Details</div>

	<table width="600">
		<tr>
			<th align="left">Pickup ID</th>
			<th align="left">Item</th>
			<th align="left">Cost</th>
			<th align="left">Status</th>
			<th align="left">Container</th>
		</tr>
		@if(count($params['products']) > 0)
			@foreach($params['products'] as $product)
				<tr>
					<td align="left">{{$product['item_id']}}</td>
					<td align="left">{{$product['product_title_new']}}</td>
					<td align="left">£{{number_format($product['sub_amount'],2)}}</td>
					<td align="left">{{($product['status_text'] !== '')?$product['status_text']:$params['status_text']}}</td>
					<td align="left">{{$product['container_name']}}</td>
				</tr>
			@endforeach
		@endif
		
	</table>
	<div>&nbsp;</div>
	<div><strong>Total:</strong> £{{number_format($params['total'],2)}}</div>
	<div>&nbsp;</div>
	<div>Regards,</div>
	<div>AgyaKoo Shipping Customer Services Team</div>
	<div>AgyaKoo Shipping</div>
	<div>31 Waleys Close, Luton, Lu3 3rz</div>
	<div>Ph:+44 7853 607006</div>
	<div>agyakooshipping.com</div>

</div>