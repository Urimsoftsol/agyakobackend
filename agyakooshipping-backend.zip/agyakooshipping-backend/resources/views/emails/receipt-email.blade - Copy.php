<div style='max-width: 600px; width: 600px; margin: 0 auto; background: #fff; border-radius: 5px; padding-bottom: 28px; font-family: Roboto, sans-serif;'>
	<link href='https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap' rel='stylesheet'>
	<table style='max-width: 600px; width: 600px; border-collapse: collapse;'>
		<tbody>
			<tr>
				<td>
					<p style='font-weight: bold; color: #008000; text-align: center; font-size: 28px; margin: 0; padding-bottom: 15px;'>Order Receipt</p>
					<p style='font-weight: bold; color: #000066; text-align: center; font-size: 16px; margin: 0; padding-bottom: 30px;'>Thank you for your order!</p>
				</td>
			</tr>
			<tr>
				<td>
					<div style='width: 540px; margin: 0 auto; padding: 15px; border: 1px solid #d5d5d5; border-radius: 5px;'>
						<table style='min-width: 510px; margin-bottom: 0px; padding: 0; border-collapse: collapse;'>
							<tbody>
								<tr>
									<td style='vertical-align: top;'>
										<p style='color: #929292; text-align: left; font-size: 15px; margin: 0; padding-bottom: 20px; font-family: Roboto, sans-serif;'>Hello <span style='color: #000066; font-weight: 500'>{{$data['name']}},</span></p>
									</td>
								</tr>
								<tr>
									<td colspan='2' style='vertical-align: top;'>
										<p style='color: #929292; text-align: left; font-size: 15px; margin: 0; padding-bottom: 20px; line-height: 25px;'><strong>Order Summary</strong></p>
									</td>
								</tr>
							</tbody>
						</table>
						<table style='min-width: 510px; margin-bottom: 0px; padding: 0; border-collapse: collapse; margin-top: 25px;'>
							<tbody>
								<tr>
									<td style='vertical-align: top; width: 50%; color: #000; text-align: left; font-size: 13px; font-weight: 600; margin: 0; padding-bottom: 6px;'>&nbsp;</td>
									<td style='vertical-align: top; width: 20%; color: #000; text-align: center; font-size: 13px; font-weight: 600; margin: 0; padding-bottom: 6px;'>Qty</td>
									<td style='vertical-align: top; width: 30%; color: #000; text-align: center; font-size: 13px; font-weight: 600; margin: 0; padding-bottom: 6px;'>Price</td>
								</tr>
								@foreach($data['products'] as $product)
									<tr>
										<td style='vertical-align: top; width: 50%; color: #333; text-align: left; font-size: 14px; margin: 0; padding-bottom: 6px; font-weight: 400;'>{{$product['product_title_new']}}</td>
										<td style='vertical-align: top; width: 20%; color: #333; text-align: center; font-size: 14px; margin: 0; padding-bottom: 6px; font-weight: 400;'>{{$product['quantity']}}</td>
										<td style='vertical-align: top; width: 30%; color: #333; text-align: center; font-size: 14px; margin: 0; padding-bottom: 6px; font-weight: 600;'>£{{number_format($product['sub_amount'],2)}}</td>
									</tr>
								@endforeach
								<tr>
									<td colspan='3' style='padding-top: 14px; border-top: 1px solid #b7b7b7; vertical-align: top;'></td>
								</tr>
								<tr>
									<td colspan='2' style='vertical-align: top; width: 70%; color: #333; text-align: left; font-size: 14px; margin: 0; padding-bottom: 6px; font-weight: 600;'>Grand Total</td>
									<td style='vertical-align: top; width: 30%; color: #333; text-align: center; font-size: 14px; margin: 0; padding-bottom: 6px; font-weight: 600;'>£{{number_format($data['amount'],2)}}</td>
								</tr>
								<tr>
									<td  colspan='3' style='padding-top: 50px; vertical-align: top; width:100%;'>
										<p style='color: #929292; text-align: left; font-size: 15px; margin: 0; line-height: 20px; font-family: Roboto, sans-serif;'>Thank you for choosing Agyakoo Shipping</p>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<div style='max-width: 600px; margin-left: auto; margin-right: auto; margin-top: 20px;'>
	<p style='color: #505050; text-align: center; font-size: 14px; margin: 0; line-height: 20px; font-family: Roboto, sans-serif;'><a style='color: #000; font-weight: 500; text-decoration: none;' href='https://agyakooshipping.com/'>Agyakoo Shipping</a> ©{{date('Y')}}. All rights reserved.</p>
</div>