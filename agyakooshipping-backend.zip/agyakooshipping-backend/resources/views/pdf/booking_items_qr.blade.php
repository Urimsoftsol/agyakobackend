@if(count($data))
	@foreach ($data as $item)
		<div style="text-align: center;">
			
			<div style="width: 200px; height:45px; background: rgb(230, 79, 34); margin: 0 auto; padding: 2px;"><img src="https://agyakooshipping.com/images/logo.svg" style="width: 200px; height:45px;"></div>
			<div style="margin: 10px auto;">
				<label style="font-size: 16px; line-height: 17px; margin: 0;">B ID:</label>
				<p style="font-size: 18px; line-height: 19px; font-weight: bold; margin: 0; text-transform: uppercase;">{{$item['booking']['reference_id']}} - {{$item['id']}}</p>
			</div>
			<div style="margin: 10px auto;">
				<label style="font-size: 16px; line-height: 17px; margin: 0;">P TYPE:</label>
				<p style="font-size: 18px; line-height: 19px; font-weight: bold; margin: 0; text-transform: uppercase;">{{$item['product_title']}}</p>
				<p style="font-size: 14px; line-height: 15px; margin: 0;">Price: £{{number_format($item['sub_amount'],2)}}</p>
			</div>
			<div style="margin: 20px auto;">
				<img src="data:image/png;base64, {!! base64_encode(QrCode::size(220)->generate(base64_encode(base64_encode('AgyakooShipping-'.$item['booking_id'].'-'.$item['id'])))) !!} ">
			</div>
			<div style="margin: 10px auto;">
				<label style="font-size: 16px; line-height: 17px; margin: 0;">R Name:</label>
				<p style="font-size: 18px; line-height: 19px; font-weight: bold; margin: 0; text-transform: uppercase;">{{$item['recepient_data']['name']}}</p>
				<label style="font-size: 16px; line-height: 17px; margin: 0;">R Address:</label>
				<p style="font-size: 18px; line-height: 19px; font-weight: bold; margin: 0; text-transform: uppercase;">{{$item['recepient_data']['address']}}</p>
				<p style="font-size: 18px; line-height: 19px; font-weight: bold; margin: 0; text-transform: uppercase;">{{$item['recepient_data']['phone']}}</p>
			</div>


		</div>
	@endforeach
@endif