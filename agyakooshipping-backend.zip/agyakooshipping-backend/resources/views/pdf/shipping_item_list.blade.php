<table cellpadding="0" cellspacing="0">
	<tr>
		<th style="border-bottom: 1px solid #000;">Container Id</th>
		<th style="border-bottom: 1px solid #000;">Booking Id</th>
		<th style="border-bottom: 1px solid #000;">Pickup Id</th>
		<th style="border-bottom: 1px solid #000;">Product</th>
		<th style="border-bottom: 1px solid #000;">Cost</th>
		<th style="border-bottom: 1px solid #000;">Recipient Name</th>
		<th style="border-bottom: 1px solid #000;">Recipient Contact</th>
		<th style="border-bottom: 1px solid #000;">Recipient Location</th>
	</tr>

	@if(count($data))
		@foreach ($data as $item)
			<tr>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['container_id']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['booking_id']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['item_id']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['title']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">£{{@$item['amount']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['recipient_name']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['recipient_contact']}}</td>
				<td style="border-bottom: 1px solid #000; text-align: center;">{{@$item['recipient_location']}}</td>
			</tr>
		@endforeach
	@endif
</table>