<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//clear cache and view
Route::get('/clear', function() {
    //$exitCode = Artisan::call('config:cache');
    //$exitCode = Artisan::call('view:clear');
    //$exitCode = Artisan::call('config:cache');
    //$exitCode = Artisan::call('view:clear');
    $exitCode = Artisan::call('cache:clear');
    $exitCode = Artisan::call('route:clear');
    $exitCode = Artisan::call('config:clear');
    $exitCode = Artisan::call('view:clear');
    return '<div style="width: 100%;
    border: 2px dotted #3dcd96;
    background: #eee;
    color: #68696d;
    text-align: center;
    border-radius: 4px;"><h1>Config & View cache cleared successfully.</h1></div>';
});


//clear cache and view
Route::get('/migrate', function() {
    $exitCode = Artisan::call('migrate');
    return '<div style="width: 100%;
    border: 2px dotted #3dcd96;
    background: #eee;
    color: #68696d;
    text-align: center;
    border-radius: 4px;"><h1>Migrated successfully.</h1></div>';
});
