  <?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\DeliveryCategoryController;
use App\Http\Controllers\DeliveryProductController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\FrontController;
use App\Http\Controllers\BookingsController;
use App\Http\Controllers\DriversController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CustomerMController;
use App\Http\Controllers\DriverAppController;
use App\Http\Controllers\ShippingContainerController;
use App\Http\Controllers\ShippingsController;
use App\Http\Controllers\WareHouseAppController;
use App\Http\Controllers\DeliveryController;
use App\Http\Controllers\MembershipController;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::group(array('prefix' => 'v1'), function() {
    Route::middleware(['cors'])->group(function(){
        //Users
        Route::get('users', [UsersController::class, 'index']);
        Route::get('users/{id}', [UsersController::class, 'show'])->where('id','[0-9]+');
        Route::post('users', [UsersController::class, 'store']);
        Route::post('users/{id}', [UsersController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('users/{id}', [UsersController::class, 'update'])->where('id','[0-9]+');
        Route::delete('users/{id}', [UsersController::class, 'delete'])->where('id','[0-9]+');

        //Drivers
        Route::get('drivers', [DriversController::class, 'index']);
        Route::get('drivers/{id}', [DriversController::class, 'show'])->where('id','[0-9]+');
        Route::post('drivers', [DriversController::class, 'store']);
        Route::post('drivers/{id}', [DriversController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('drivers/{id}', [DriversController::class, 'update'])->where('id','[0-9]+');
        Route::delete('drivers/{id}', [DriversController::class, 'delete'])->where('id','[0-9]+');
        Route::post('drivers-password-change/{id}', [DriversController::class, 'changePassword'])->where('id','[0-9]+');


        //Customers
        Route::get('customers', [CustomerController::class, 'index']);
        Route::get('customers/{id}', [CustomerController::class, 'show'])->where('id','[0-9]+');
        Route::post('customers', [CustomerController::class, 'store']);
        Route::post('customers/{id}', [CustomerController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('customers/{id}', [CustomerController::class, 'update'])->where('id','[0-9]+');
        Route::delete('customers/{id}', [CustomerController::class, 'delete'])->where('id','[0-9]+');
        Route::post('add-membership', [CustomerController::class, 'addMembership'])->where('id','[0-9]+');

        //User Permission
        Route::get('users-permission-parent-list', [PermissionController::class, 'userPermissionParentList']);
        Route::get('users-permission-list', [PermissionController::class, 'userPermissionList']);
        // Route::get('users/{id}', [UsersController::class, 'show'])->where('id','[0-9]+');
        Route::post('users-permission-add', [PermissionController::class, 'usersPermissionAdd']);
        Route::post('add-role-permission', [PermissionController::class, 'addRolePermission']);
        Route::post('delete-role-permission', [PermissionController::class, 'deleteRolePermission']);

        //Categories
        Route::get('categories', [CategoryController::class, 'index']);
        Route::get('categories/{id}', [CategoryController::class, 'show'])->where('id','[0-9]+');
        Route::post('categories', [CategoryController::class, 'store']);
        Route::post('categories/{id}', [CategoryController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('categories/{id}', [CategoryController::class, 'update'])->where('id','[0-9]+');
        Route::delete('categories/{id}', [CategoryController::class, 'delete'])->where('id','[0-9]+');

        //Products
        Route::get('products', [ProductController::class, 'index']);
        Route::get('category-list', [ProductController::class, 'categoryList']);
        Route::get('products/{id}', [ProductController::class, 'show'])->where('id','[0-9]+');
        Route::post('products', [ProductController::class, 'store']);
        Route::post('products/{id}', [ProductController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('products/{id}', [ProductController::class, 'update'])->where('id','[0-9]+');
        Route::delete('products/{id}', [ProductController::class, 'delete'])->where('id','[0-9]+');

        //Delivery Categories
        Route::get('delivery-categories', [DeliveryCategoryController::class, 'index']);
        Route::get('delivery-categories/{id}', [DeliveryCategoryController::class, 'show'])->where('id','[0-9]+');
        Route::post('delivery-categories', [DeliveryCategoryController::class, 'store']);
        Route::post('delivery-categories/{id}', [DeliveryCategoryController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('delivery-categories/{id}', [DeliveryCategoryController::class, 'update'])->where('id','[0-9]+');
        Route::delete('delivery-categories/{id}', [DeliveryCategoryController::class, 'delete'])->where('id','[0-9]+');

        //Delivery Products
        Route::get('delivery-products', [DeliveryProductController::class, 'index']);
        Route::get('delivery-category-list', [DeliveryProductController::class, 'categoryList']);
        Route::get('delivery-products/{id}', [DeliveryProductController::class, 'show'])->where('id','[0-9]+');
        Route::post('delivery-products', [DeliveryProductController::class, 'store']);
        Route::post('delivery-products/{id}', [DeliveryProductController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('delivery-products/{id}', [DeliveryProductController::class, 'update'])->where('id','[0-9]+');
        Route::delete('delivery-products/{id}', [DeliveryProductController::class, 'delete'])->where('id','[0-9]+');

            //Membership Management
        Route::get('memberships', [MembershipController::class, 'index']);
        Route::get('membership-list', [MembershipController::class, 'getMembershipList']);
        Route::get('memberships/{id}', [MembershipController::class, 'show'])->where('id','[0-9]+');
        Route::post('memberships', [MembershipController::class, 'store']);
        Route::post('memberships/{id}', [MembershipController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('memberships/{id}', [MembershipController::class, 'update'])->where('id','[0-9]+');
        Route::delete('memberships/{id}', [MembershipController::class, 'delete'])->where('id','[0-9]+');    
        
        //Auth
        Route::post('login', [AuthController::class, 'login']);
        Route::post('signup', [AuthController::class, 'signup']);
        Route::post('logout', [AuthController::class, 'logout']);

        //Forgot Password
        Route::post('forgot-password/email',  [ForgotPasswordController::class, 'sendmail']);
        Route::post('forgot-password/code/check', [ForgotPasswordController::class, 'checkcode']);
        Route::post('forgot-password/reset', [ForgotPasswordController::class, 'reset']);

        //Bookings
        Route::get('bookings', [BookingsController::class, 'index']);
        Route::get('bookings/{id}', [BookingsController::class, 'show'])->where('id','[0-9]+');
        Route::get('bookings-details/{id}', [BookingsController::class, 'show2'])->where('id','[0-9]+');
        Route::post('bookings', [BookingsController::class, 'store']);
        Route::post('bookings/{id}', [BookingsController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('bookings/{id}', [BookingsController::class, 'update'])->where('id','[0-9]+');
        Route::delete('bookings/{id}', [BookingsController::class, 'delete'])->where('id','[0-9]+');
        Route::get('bookings-enquery/{booking_id}', [BookingsController::class, 'getBookingProducts']);
        Route::get('bookings-item-pdf/{id}', [BookingsController::class, 'getBookingItemPDF'])->where('id','[0-9]+');
        Route::get('assign-bookings', [BookingsController::class, 'assignBookings']);
        Route::get('assigned-bookings', [BookingsController::class, 'assignedBookings']);
        Route::get('picked-item', [BookingsController::class, 'getPickedItem']);
        Route::post('make-as-received', [BookingsController::class, 'makeAsReceived']);
        Route::get('sendtestmail/{booking_id}', [BookingsController::class, 'sendTestMail']);
        Route::post('add-payment/{booking_id}', [BookingsController::class, 'addPayment']);
        Route::get('driver-report', [BookingsController::class, 'getDriverReport']);

        //Shipping
        Route::get('containers', [ShippingContainerController::class, 'index']);
        Route::get('containers/{id}', [ShippingContainerController::class, 'show'])->where('id','[0-9]+');
        Route::post('containers', [ShippingContainerController::class, 'store']);
        Route::put('containers/{id}', [ShippingContainerController::class, 'update'])->where('id','[0-9]+');
        Route::delete('containers/{id}', [ShippingContainerController::class, 'delete'])->where('id','[0-9]+');
        Route::get('shippings', [ShippingsController::class, 'index']);
        Route::get('shippings/{id}', [ShippingsController::class, 'show'])->where('id','[0-9]+');
        Route::post('shippings', [ShippingsController::class, 'store']);
        Route::post('shippings/{id}', [ShippingsController::class, 'updateAll'])->where('id','[0-9]+');
        Route::put('shippings/{id}', [ShippingsController::class, 'update'])->where('id','[0-9]+');
        Route::delete('shippings/{id}', [ShippingsController::class, 'delete'])->where('id','[0-9]+');
        Route::get('shippings/booking-list-wh', [ShippingsController::class, 'getBookingListWh']);
        Route::get('shippings/booking-list-con/{container_id}', [ShippingsController::class, 'getBookingListCon'])->where('container_id','[0-9]+');
        Route::get('shippings/booking-list/{shipping_id}', [ShippingsController::class, 'getBookingList'])->where('shipping_id','[0-9]+');
        Route::get('shippings-item-pdf/{shipping_id}', [ShippingsController::class, 'getShippingItemPDF'])->where('shipping_id','[0-9]+');
        Route::get('item-loaded/{containerId}/{bookingId}', [ShippingsController::class, 'bookingLoadedToConatiner']);
        Route::get('item-loaded/{containerId}/{bookingId}/{bookingPId}', [ShippingsController::class, 'itemLoadedToConatiner']);
        Route::get('item-unloaded/{containerId}/{bookingId}', [ShippingsController::class, 'bookingUnLoadedToConatiner']);
        Route::get('item-unloaded/{containerId}/{bookingId}/{bookingPId}', [ShippingsController::class, 'itemUnLoadedToConatiner']);
        Route::get('marked-container/{id}', [ShippingsController::class, 'markedContainer']);
        Route::get('cancel-shipping/{id}', [ShippingsController::class, 'cancelShipping']);

        //Delivery
        Route::get('delivery/shipping-dd-list', [DeliveryController::class, 'getShippingDDList']);
        Route::get('delivery/shipping-details/{id}', [DeliveryController::class, 'getShippingDetails']);
        Route::get('delivery/shipping-received/{id}', [DeliveryController::class, 'getShippingReceived']);
        Route::get('delivery/booking-list-ship/{ship_id}', [DeliveryController::class, 'getBookingListShip']);
        Route::get('delivery/item-received/{shipping_id}/{booking_id}/{item_id}', [DeliveryController::class, 'itemReceived']);
        Route::get('delivery/item-received-all/{shipping_id}/{booking_id}', [DeliveryController::class, 'itemReceivedAll']);
        Route::get('delivery/assign-bookings', [DeliveryController::class, 'assignBookings']);
        Route::get('delivery/driver-dd-list', [DeliveryController::class, 'getPickupDriverDDList']);
        Route::post('delivery/assign-bookings', [DeliveryController::class, 'assignDriverBookings']);
        Route::post('delivery/unassign-bookings', [DeliveryController::class, 'unassignBookings']);
        Route::post('delivery/reassign-bookings', [DeliveryController::class, 'reassignBookings']);
        Route::get('delivery/assigned-bookings', [DeliveryController::class, 'assignedBookings']);
        Route::post('delivery/make-as-delivered', [DeliveryController::class, 'makeAsDelivered']);



        //Admin
        Route::get('adresses/{user_id}/{type}', [AdminController::class, 'getUserAddresses']);
        Route::get('p-driver-dd-list', [AdminController::class, 'getPickupDriverDDList']);
        Route::post('assign-bookings', [AdminController::class, 'assignBookings']);
        Route::post('unassign-bookings', [AdminController::class, 'unassignBookings']);
        Route::post('reassign-bookings', [AdminController::class, 'reassignBookings']);

        //Front
        Route::post('add-customer', [FrontController::class, 'addCustomer']);
        Route::get('customer-dd-list', [FrontController::class, 'getCustomerDDList']);
        Route::get('container-dd-list/{isAdd}', [FrontController::class, 'getContainerDDList']);
        Route::get('delivery-product-dd-list', [FrontController::class, 'getDeliveryProductList']);
        Route::get('product-dd-list', [FrontController::class, 'getProductList']);
        Route::post('add-booking', [FrontController::class, 'addBooking']);
        Route::get('address-list/{type}', [FrontController::class, 'getAddressList']);
        Route::get('tarck-booking-details/{id}', [FrontController::class, 'getBookingDetails']);
        Route::post('contact-us', [FrontController::class, 'contactUs']);

        //Customer
        Route::get('customer-booking-list', [CustomerMController::class, 'getBookingList']);
        Route::post('update-profile', [CustomerMController::class, 'updateProfile']);
        Route::post('change-password', [CustomerMController::class, 'changePassword']);
        Route::get('customer-booking-details/{id}', [CustomerMController::class, 'getBookingDetails']);


        Route::get('test-track', [AdminController::class, 'testTrack']);

        Route::get('dashboard/get-data', [UsersController::class, 'getDashboardData']);

        //Driver App
        Route::group(array('prefix' => 'driver'), function() {
            Route::post('login', [DriverAppController::class, 'login']);
            Route::get('today-request-list', [DriverAppController::class, 'getTodayRequests']);
            Route::get('request-list', [DriverAppController::class, 'getRequests']);
            Route::get('request-details/{id}', [DriverAppController::class, 'getRequestDetails']);
            Route::get('address-details/{id}', [DriverAppController::class, 'getAddressDetails']);
            Route::put('address-details/{id}', [DriverAppController::class, 'updateAddressDetails']);
            Route::put('cancel-bookings/{id}', [DriverAppController::class, 'cancelBookings']);
            Route::get('booking-item-details/{id}', [DriverAppController::class, 'bookingItemDetails']);
            Route::post('item-picked-up', [DriverAppController::class, 'bookingPickedUp']);
            Route::get('product-dd-list', [DriverAppController::class, 'getProductList']);
            Route::post('update-items', [DriverAppController::class, 'updateItems']);
            Route::get('customer-dd-list', [DriverAppController::class, 'getCustomerDDList']);
            Route::get('adresses/{user_id}/{type}', [DriverAppController::class, 'getUserAddresses']);
            Route::post('booking', [DriverAppController::class, 'addBooking']);
            Route::post('add-customer', [DriverAppController::class, 'addCustomer']);
            Route::post('upload-image', [DriverAppController::class, 'uploadImage']);
            Route::post('upload-multiple-images', [DriverAppController::class, 'uploadImages']);
            Route::get('send-mail/{id}', [DriverAppController::class, 'sendEmail']);
            Route::get('qr-list/{id}', [DriverAppController::class, 'getQRList']);
            Route::get('download-qr-pdf/{id}', [DriverAppController::class, 'downloadQRPdf'])->where('id','[0-9]+');
            Route::get('download-receipt/{id}', [DriverAppController::class, 'downloadReceipt'])->where('id','[0-9]+');
            Route::get('product-dd-list-new', [DriverAppController::class, 'getProductListNew']);

            Route::group(array('prefix' => 'delivery'), function() {
                Route::get('request-list', [DriverAppController::class, 'getDeliveryRequests']);
                Route::get('request-details/{id}', [DriverAppController::class, 'getDeliveryRequestDetails']);
                Route::get('booking-item-details/{id}', [DriverAppController::class, 'bookingDeliveryItemDetails']);
                Route::post('item-deliverred', [DriverAppController::class, 'bookingDeliverred']);
                Route::post('upload-image', [DriverAppController::class, 'uploadDeliveryImage']);
                Route::post('upload-multiple-images', [DriverAppController::class, 'uploadDeliveryImages']);
            });
        });

        //Warehouse App
        Route::group(array('prefix' => 'warehouse'), function() {
            Route::post('login', [WareHouseAppController::class, 'login']);
            Route::get('driver-list', [WareHouseAppController::class, 'getDriverList']);
            Route::get('booking-item-list/{driverId}', [WareHouseAppController::class, 'getBookingItemList']);
            Route::get('warehouse-item-list', [WareHouseAppController::class, 'getWarehouseItemList']);
            Route::get('item-received/{str}', [WareHouseAppController::class, 'changeItemReceived']);
            Route::get('container-list', [WareHouseAppController::class, 'getContainerList']);
            Route::get('container-item-list/{containerId}', [WareHouseAppController::class, 'getContainerItemList']);
            Route::get('item-loaded/{containerId}/{str}', [WareHouseAppController::class, 'changeItemLoaded']);
            Route::get('shipping-container-list', [WareHouseAppController::class, 'getShippingContainerList']);
            Route::get('shipping-container-item-list/{shippingId}', [WareHouseAppController::class, 'getShippingContainerItemList']);
        });
    });
});
